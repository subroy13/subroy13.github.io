---
title: "Paper Figures"
id: "paper-figures"
subtitle: "Enlarged Figures From the Paper"
clickable: true
---
