#####################
devtools::install('../../Software Packages/R/rsvddpd/')

library(av)
library(imager)
library(rsvddpd)

frames_to_matrix <- function(images, channel_index = 1) {
    shapes <- dim(images[[1]])
    
    # convert each image into a column
    M <- matrix(0, nrow = shapes[1] * shapes[2], ncol = length(images))
    
    for (i in 1:length(images)) {
        tmp <- channel(images[[i]], channel_index)
        M[, i] <- as.numeric(tmp)
    }
    return(M)
}

matrix_to_frame <- function(M, fr, shapes, savepath = NULL, type = "bg", resize_scale = NULL) {
    if (is.list(M)) {
        tmp <- array(dim = c(shapes[1], shapes[2], 1, 3))
        tmp[,,1,1] <- M[[1]][[type]][, fr]
        tmp[,,1,2] <- M[[2]][[type]][, fr]
        tmp[,,1,3] <- M[[3]][[type]][, fr]
        tmp <- as.cimg(tmp)
        if (!is.null(savepath)) {
            if (!is.null(resize_scale)) {
                tmp <- imresize(tmp, scale = resize_scale)
            }
            save.image(tmp, savepath)
        }
        plot(tmp)
    } else {
        tmp <- M[, fr] / (max(M[, fr]) - min(M[, fr]))
        dim(tmp) <- c(shapes[1],shapes[2], 1, 1)
        tmp <- as.cimg(tmp)
        if (!is.null(savepath)) {
            save.image(tmp, savepath)
        }
        plot(tmp)
    }
}


###########################################
# Video Processing (Analysis of Freeway video sequence)

path <- './Datasets/JPEGS/freeway/'
imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)

M <- frames_to_matrix(images)
matrix_to_frame(M, 10, shapes = dim(images[[1]])[1:2])
M <- 0.3 * M
set.seed(12345)
M[sample(1:nrow(M), size = 5000), sample(1:ncol(M), size = 1) + 1:5 - 1] <- 1
which(apply(M, 2, FUN = function(x) sum(x==1) ) > 0)  # index of bad / corrupted frames

matrix_to_frame(M, 6, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/true_frame14.jpg')
matrix_to_frame(M, 40, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/true_frame5.jpg')
matrix_to_frame(M, 11, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/true_frame18.jpg')
matrix_to_frame(M, 37, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/true_frame42.jpg')

# svd reconstruction
res <- svd(M, nu = 1, nv = 1)
Mhat <- res$d[1] * res$u %*% t(res$v)
matrix_to_frame(Mhat, 40, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_bg_frame5.jpg')
matrix_to_frame(M - Mhat, 40, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_fg_frame5.jpg')
matrix_to_frame(Mhat, 11, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_bg_frame18.jpg')
matrix_to_frame(M - Mhat, 11, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_fg_frame18.jpg')
matrix_to_frame(Mhat, 37, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_bg_frame42.jpg')
matrix_to_frame(M - Mhat, 37, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/svd_fg_frame42.jpg')


y <- cv.alpha(M)
y   # minimizer is 0.778

# rsvddpd reconstruction
res2 <- rSVDdpd(M, alpha = 0.778, nd = 1)
Mhat2 <- res2$d[1] * res2$u %*% t(res2$v)
matrix_to_frame(Mhat2, 40, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_bg_frame5.jpg')
matrix_to_frame(M - Mhat2, 40, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_fg_frame5.jpg')
matrix_to_frame(Mhat2, 11, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_bg_frame18.jpg')
matrix_to_frame(M - Mhat2, 11, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_fg_frame18.jpg')
matrix_to_frame(Mhat2, 37, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_bg_frame42.jpg')
matrix_to_frame(M - Mhat2, 37, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/freeway/rsvd_fg_frame42.jpg')


############################################
# Video Processing (Pedestrian Data)

path <- './Datasets/JPEGS/peds/'
imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
M <- frames_to_matrix(images)
matrix_to_frame(M, 1, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/true_frame1.jpg')
matrix_to_frame(M, 107, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/true_frame107.jpg')
matrix_to_frame(M, 170, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/true_frame170.jpg')


# Usual SVD
res <- svd(M, nu = 1, nv = 1)
Mhat <- res$d[1] * res$u %*% t(res$v)
matrix_to_frame(Mhat, 1, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_bg_frame1.jpg')
matrix_to_frame(M - Mhat, 1, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_fg_frame1.jpg')
matrix_to_frame(Mhat, 107, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_bg_frame107.jpg')
matrix_to_frame(M - Mhat, 107, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_fg_frame107.jpg')
matrix_to_frame(Mhat, 170, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_bg_frame170.jpg')
matrix_to_frame(M - Mhat, 170, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/svd_fg_frame170.jpg')


y <- cv.alpha(M, alphas = 11)
y   # optimal alpha = 1

res2 <- rSVDdpd(M, alpha = 1, nd = 1)
Mhat2 <- res2$d[1] * res2$u %*% t(res2$v)
matrix_to_frame(Mhat2, 1, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_bg_frame1.jpg')
matrix_to_frame(M - Mhat2, 1, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_fg_frame1.jpg')
matrix_to_frame(Mhat2, 107, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_bg_frame107.jpg')
matrix_to_frame(M - Mhat2, 107, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_fg_frame107.jpg')
matrix_to_frame(Mhat2, 170, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_bg_frame170.jpg')
matrix_to_frame(M - Mhat2, 170, shapes = dim(images[[1]])[1:2], savepath = './Code/figures/peds/rsvd_fg_frame170.jpg')

############################
# Video Processing (Boats)

path <- './Datasets/JPEGS/boats/'
imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
M <- frames_to_matrix(images)
dim(M)

#svd
res <- svd(M, nu = 1, nv = 1)
Mhat <- res$d[1] * res$u %*% t(res$v)

# rsvddpd
y <- cv.alpha(M, alphas = 11)
y   # optimal alpha = 0.6

res2 <- rSVDdpd(M, alpha = 0.6, nd = 1, maxiter = 500)
Mhat2 <- res2$d[1] * res2$u %*% t(res2$v)

matrix_to_frame(M, 1,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/true_frame1.jpg')
matrix_to_frame(Mhat, 1,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_bg_frame1.jpg')
matrix_to_frame(M - Mhat, 1,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_fg_frame1.jpg')
matrix_to_frame(Mhat2, 1,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_bg_frame1.jpg')
matrix_to_frame(M - Mhat2, 1,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_fg_frame1.jpg')

matrix_to_frame(M, 5,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/true_frame13.jpg')
matrix_to_frame(Mhat, 5,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_bg_frame13.jpg')
matrix_to_frame(M - Mhat, 5,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_fg_frame13.jpg')
matrix_to_frame(Mhat2, 5,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_bg_frame13.jpg')
matrix_to_frame(M - Mhat2, 5,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_fg_frame13.jpg')

matrix_to_frame(M, 21,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/true_frame28.jpg')
matrix_to_frame(Mhat, 21,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_bg_frame28.jpg')
matrix_to_frame(M - Mhat, 21,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/svd_fg_frame28.jpg')
matrix_to_frame(Mhat2, 21,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_bg_frame28.jpg')
matrix_to_frame(M - Mhat2, 21,  shapes = dim(images[[1]])[1:2], savepath = './Code/figures/boats/rsvd_fg_frame28.jpg')

############################################
# Video Processing (UHCD Data)

##########################################
# Video Stream 1
path <- './Datasets/UCHD/Stream1_images/'
av_video_images('./Datasets/UCHD/Stream1.mp4', destdir = path, fps = 1)

imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
images <- lapply(images, imsub, x > 40 & x < 280)
images <- lapply(images, imresize, scale = 0.5)

M <- list(frames_to_matrix(images, channel_index = 1), frames_to_matrix(images, channel_index = 2), frames_to_matrix(images, channel_index = 3))
dim(M[[1]])

# SVD 
res <- lapply(1:3, FUN = function(i) {
    y <- svd(M[[i]], nu = 1, nv = 1)
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})

# rSVDdpd
alphas <- c(0.6, 0.3, 1)
res2 <- lapply(1:3, FUN = function(i) {
    y <- rSVDdpd(M[[i]], nd = 1, alpha = alphas[[i]])
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})


plot(images[[5]])
save.image(imresize(images[[5]], scale = 2), file = './Code/figures/stream1/true_frame5.jpg')
matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/svd_bg_frame5.jpg', resize_scale = 2)
matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/svd_fg_frame5.jpg', resize_scale = 2)
matrix_to_frame(res2, 5, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/rsvd_bg_frame5.jpg', resize_scale = 2)
matrix_to_frame(res2, 5, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/rsvd_fg_frame5.jpg', resize_scale = 2)

plot(images[[50]])
save.image(imresize(images[[50]], scale = 2), file = './Code/figures/stream1/true_frame50.jpg')
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/svd_bg_frame50.jpg', resize_scale = 2)
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/svd_fg_frame50.jpg', resize_scale = 2)
matrix_to_frame(res2, 50, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/rsvd_bg_frame50.jpg', resize_scale = 2)
matrix_to_frame(res2, 50, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/rsvd_fg_frame50.jpg', resize_scale = 2)

plot(images[[75]])
save.image(imresize(images[[75]], scale = 2), file = './Code/figures/stream1/true_frame75.jpg')
matrix_to_frame(res, 75, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/svd_bg_frame75.jpg', resize_scale = 2)
matrix_to_frame(res, 75, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/svd_fg_frame75.jpg', resize_scale = 2)
matrix_to_frame(res2, 75, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream1/rsvd_bg_frame75.jpg', resize_scale = 2)
matrix_to_frame(res2, 75, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream1/rsvd_fg_frame75.jpg', resize_scale = 2)

##################################
# Video stream 2
path <- './Datasets/UCHD/Stream2_images/'
av_video_images('./Datasets/UCHD/Stream2.mp4', destdir = path, fps = 1)

imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
images <- lapply(images, imsub, x > 40 & x < 280)
images <- lapply(images, grayscale)

M <- frames_to_matrix(images)
dim(M)

# SVD 
y <- svd(M, nu = 1, nv = 1)
Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])

# rSVDdpd
y2 <- rSVDdpd(M, nd = 1, alpha = 1)
Mhat2 <- y2$d[1] * y2$u[, 1] %*% t(y2$v[, 1])

matrix_to_frame(M, 30, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/true_frame30.jpg')
matrix_to_frame(Mhat, 30, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/svd_bg_frame30.jpg')
matrix_to_frame(M - Mhat, 30, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/svd_fg_frame30.jpg')
matrix_to_frame(Mhat2, 30, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/rsvd_bg_frame30.jpg')
matrix_to_frame(M - Mhat2, 30, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/rsvd_fg_frame30.jpg')

matrix_to_frame(M, 60, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/true_frame60.jpg')
matrix_to_frame(Mhat, 60, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/svd_bg_frame60.jpg')
matrix_to_frame(M - Mhat, 60, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/svd_fg_frame60.jpg')
matrix_to_frame(Mhat2, 60, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/rsvd_bg_frame60.jpg')
matrix_to_frame(M - Mhat2, 60, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/rsvd_fg_frame60.jpg')

matrix_to_frame(M, 100, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/true_frame100.jpg')
matrix_to_frame(Mhat, 100, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/svd_bg_frame100.jpg')
matrix_to_frame(M - Mhat, 100, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/svd_fg_frame100.jpg')
matrix_to_frame(Mhat2, 100, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream2/rsvd_bg_frame100.jpg')
matrix_to_frame(M - Mhat2, 100, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream2/rsvd_fg_frame100.jpg')


#####################################
# STREAM 3
path <- './Datasets/UCHD/Stream3_images/'
av_video_images('./Datasets/UCHD/Stream3.mp4', destdir = path, fps = 0.5)

imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
images <- lapply(images, imsub, x > 40 & x < 280)

M <- list(frames_to_matrix(images, channel_index = 1), frames_to_matrix(images, channel_index = 2), frames_to_matrix(images, channel_index = 3))

# SVD 
res <- lapply(1:3, FUN = function(i) {
    y <- svd(M[[i]], nu = 1, nv = 1)
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})

# rSVDdpd
alphas <- c(1, 0.55, 1)
res2 <- lapply(1:3, FUN = function(i) {
    y <- rSVDdpd(M[[i]], nd = 1, alpha = alphas[[i]])
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})

plot(images[[10]])
save.image(images[[10]], file = './Code/figures/stream3/true_frame10.jpg')
matrix_to_frame(res, 10, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/svd_bg_frame10.jpg')
matrix_to_frame(res, 10, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/svd_fg_frame10.jpg')
matrix_to_frame(res2, 10, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/rsvd_bg_frame10.jpg')
matrix_to_frame(res2, 10, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/rsvd_fg_frame10.jpg')

plot(images[[31]])
save.image(images[[31]], file = './Code/figures/stream3/true_frame31.jpg')
matrix_to_frame(res, 31, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/svd_bg_frame31.jpg')
matrix_to_frame(res, 31, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/svd_fg_frame31.jpg')
matrix_to_frame(res2, 31, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/rsvd_bg_frame31.jpg')
matrix_to_frame(res2, 31, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/rsvd_fg_frame31.jpg')

plot(images[[44]])
save.image(images[[44]], file = './Code/figures/stream3/true_frame44.jpg')
matrix_to_frame(res, 44, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/svd_bg_frame44.jpg')
matrix_to_frame(res, 44, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/svd_fg_frame44.jpg')
matrix_to_frame(res2, 44, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream3/rsvd_bg_frame44.jpg')
matrix_to_frame(res2, 44, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream3/rsvd_fg_frame44.jpg')

###################################################
# Video Stream 4
path <- './Datasets/UCHD/Stream4_images/'
av_video_images('./Datasets/UCHD/Stream4.mp4', destdir = path, fps = 2)

imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
images <- lapply(images, imsub, x > 40 & x < 280)
images <- images[1:80]  # take only the first few frames of moved camera tampering

M <- list(frames_to_matrix(images, channel_index = 1), frames_to_matrix(images, channel_index = 2), frames_to_matrix(images, channel_index = 3))
dim(M[[1]])

# SVD 
res <- lapply(1:3, FUN = function(i) {
    y <- svd(M[[i]], nu = 1, nv = 1)
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})

# rSVDdpd
alphas <- c(1, 1, 1)
res2 <- lapply(1:3, FUN = function(i) {
    y <- rSVDdpd(M[[i]], nd = 1, alpha = alphas[[i]])
    Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
    return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
})

plot(images[[5]])
save.image(images[[5]], file = './Code/figures/stream4/true_frame5.jpg')
matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/svd_bg_frame5.jpg')
matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/svd_fg_frame5.jpg')
matrix_to_frame(res2, 5, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/rsvd_bg_frame5.jpg')
matrix_to_frame(res2, 5, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/rsvd_fg_frame5.jpg')

plot(images[[50]])
save.image(images[[50]], file = './Code/figures/stream4/true_frame50.jpg')
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/svd_bg_frame50.jpg')
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/svd_fg_frame50.jpg')
matrix_to_frame(res2, 50, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/rsvd_bg_frame50.jpg')
matrix_to_frame(res2, 50, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/rsvd_fg_frame50.jpg')

plot(images[[76]])
save.image(images[[76]], file = './Code/figures/stream4/true_frame76.jpg')
matrix_to_frame(res, 76, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/svd_bg_frame76.jpg')
matrix_to_frame(res, 76, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/svd_fg_frame76.jpg')
matrix_to_frame(res2, 76, shapes = dim(images[[1]]), type = "bg", savepath = './Code/figures/stream4/rsvd_bg_frame76.jpg')
matrix_to_frame(res2, 76, shapes = dim(images[[1]]), type = "fg", savepath = './Code/figures/stream4/rsvd_fg_frame76.jpg')

#########################################
# Financial Application

library(readr)
library(dplyr)
library(tidyr)
library(lubridate)
library(ggplot2)
library(gghighlight)
library(rsvddpd)
library(pcaMethods)
library(RobRSVD)


dat <- read_csv('./Datasets/NIFTY50_all.csv')
nifty <- read_csv('./Datasets/nifty-index.csv')
nifty <- nifty %>% mutate(Date = lubridate::dmy(Date), Symbol = "NIFTY50") %>%
    select(Date, Symbol, Open, High, Low, Close)
fulldata <- dat %>% 
    dplyr::filter(Date > as.Date('2020-03-31'), Date < as.Date('2020-10-01')) %>% 
    select(Date, Symbol, Open, High, Low, Close) %>%
    add_row(nifty)

ggplot(fulldata) +
    geom_line(aes(x = Date, y = Close, color = Symbol), size = 1) +
    gghighlight((substr(Symbol, 1,1) == "E") | (Symbol == "NIFTY50"), label_params = list(size = 5)) +
    theme_bw() +
    ylab("Closing Price") + 
    scale_x_date(breaks = scales::pretty_breaks(n = 10)) +
    theme(axis.title = element_text(size = 16), axis.text = element_text(size = 12))
ggsave("NIFTY50-all.pdf", device = "pdf", width = 12, height = 6)



# close price matrix
x <- fulldata %>%
    dplyr::filter(Symbol != "NIFTY50") %>%
    pivot_wider(Date, names_from = "Symbol", values_from = "Close")

x_mat <- as.matrix(x[, -1])
colnames(x_mat) <- colnames(x)[-1]

y1 <- svd(x_mat, nu = 1, nv = 1)
y2 <- robustSvd(x_mat)
y3 <- RobRSVD(x_mat, irobust = T, iugcv = F, ivgcv = F)
y4 <- RobRSVD(x_mat, irobust = T, iugcv = T, ivgcv = T)

cv.alpha(x_mat, alphas = 11)
y5 <- rSVDdpd(x_mat, alpha = 1, nd = 1)


result <- tibble(Date = nifty$Date, 
                 NIFTY50 = nifty$Close,
                 SVD = y1$u[,1]  * mean(nifty$Close) / mean(y1$u[, 1]),
                 pcaSVD = y2$u[, 1] * mean(nifty$Close) / mean(y2$u[, 1]), 
                 RobSVD = y3$u[, 1] * mean(nifty$Close) / mean(y3$u[, 1]), 
                 RobRSVD = y4$u[, 1] * mean(nifty$Close) / mean(y4$u[, 1]), 
                 rSVDdpd = y5$u[, 1] * mean(nifty$Close) / mean(y5$u[, 1]) )

result %>%
    pivot_longer(-Date, names_to = "Index", values_to = "Value") %>% 
    ggplot() +
    geom_line(aes(x = Date, y = Value, color = Index), size = 1) +
    theme_bw() +
    ylab("Value of the Index") +
    scale_x_date(breaks = scales::pretty_breaks(n = 10))

ggsave("NIFTY50-index.pdf", device = "pdf", width = 12, height = 6)





