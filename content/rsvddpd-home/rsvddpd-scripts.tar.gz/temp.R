library(imager)
library(stringr)

get.synth.filepaths <- function(rootpath) {
    synth1.list <- list.files(file.path(rootpath, 'synth1'))
    synth2.list <- list.files(file.path(rootpath, 'synth2'))
    files <- c(
        file.path(rootpath, 'synth1', synth1.list[-grep("_gt.mp4", synth1.list)]),
        file.path(rootpath, 'synth2', synth2.list[-grep("_gt.mp4", synth2.list)])
    )
    gt_files <- c(
        file.path(rootpath, 'synth1', synth1.list[grep("_gt.mp4", synth1.list)]),
        file.path(rootpath, 'synth2', synth2.list[grep("_gt.mp4", synth2.list)])
    )
    names(files) <- names(gt_files) <- as.character(str_match(files, "[0-9]{3,}"))
    return(list("video" = files, "gt" = gt_files,
                "name" = substring(basename(files), 1, 3) ))
}

f <- get.synth.filepaths('./data/BMC')


# Generate GIF files for Main Video and GT
for (b in seq(2, 20, 2)) {
    message(paste0("================ Processing File ", b))
    
    message("Loading Main Video")
    video <- load.video(f$video[b], fps = 2)   # use FPS = 2 for memory size issue
    video <- grayscale(video)
    outpath <- paste0('./site/static/BMC/video', f$name[b], '.gif')
    save.video(video, outpath)
    
    message("Loading Ground Truth")
    gt <- load.video(f$gt[b], fps = 2)   # use FPS = 2 for memory size issue
    outpath <- paste0('./site/static/BMC/gt', f$name[b], '.gif')
    save.video(gt, outpath)
    
    #methods <- c("ALM", "GoDec", "grasta", "OP", "rpca", "rsvddpd", "SRPCP", "svd", "VB")
    methods <- c("rsvddpd2", "rsvddpd4")
    for (m in methods) {
        message(paste0("Loading Method ", m))
        
        bgm <- grayscale(load.video(paste0('./output/BMC/',m,'/bg-',f$name[b],'.mp4')))
        bgm <- video - bgm
        outpath <- paste0('./site/static/BMC/', m,'-', f$name[b], '.gif')
        save.video(bgm, outpath)
    }
    
}

####################################

rootpath <- './output/UHCTD'
f <- list.files(rootpath)

for (i in f[25:32]) {
    message(paste0('Processing video ', i))
    filepath <- paste0(rootpath, '/', i)
    outpath <- paste0(rootpath, '/reduced/', i)
    video <- load.video(filepath)
    save.video(video, outpath, fps = 5)
}














