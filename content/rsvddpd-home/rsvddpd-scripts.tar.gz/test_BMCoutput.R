#######################
# LOAD REQUIRED PACKAGES
library(imager)
library(stringr)
library(readr)

get.synth.filepaths <- function(rootpath) {
    synth1.list <- list.files(file.path(rootpath, 'synth1'))
    synth2.list <- list.files(file.path(rootpath, 'synth2'))
    files <- c(
        file.path(rootpath, 'synth1', synth1.list[-grep("_gt.mp4", synth1.list)]),
        file.path(rootpath, 'synth2', synth2.list[-grep("_gt.mp4", synth2.list)])
    )
    gt_files <- c(
        file.path(rootpath, 'synth1', synth1.list[grep("_gt.mp4", synth1.list)]),
        file.path(rootpath, 'synth2', synth2.list[grep("_gt.mp4", synth2.list)])
    )
    names(files) <- names(gt_files) <- as.character(str_match(files, "[0-9]{3,}"))
    return(list("video" = files, "gt" = gt_files))
}

get.measures <- function(methodname) {
    f <- get.synth.filepaths('./data/BMC')
    indices <- 1:20
    thresh <- seq(0.01, 0.3, 0.01)
    pb <- txtProgressBar(max = length(thresh) * 20, style = 3) 
    dflist <- list()
    
    for (index in indices) {
        #trainIndex <- 2 * index - 1
        #testIndex <- 2 * index
        trainIndex <- index
        
        video <- grayscale(load.video(f$video[trainIndex], fps = 2))
        gt <- grayscale(load.video(f$gt[trainIndex], fps = 2))
        bgpath <- paste0('./output/BMC/', methodname, '/bg-', names(f$video)[trainIndex], '.mp4')
        bg <- grayscale(load.video(bgpath, fps = 2))
        fg <- abs(video - bg)
        
        precs <- numeric(length(thresh))
        recalls <- numeric(length(thresh))
        for (i in 1:length(thresh)) {
            fg.thresh <- (fg > thresh[i])
            precs[i] <- sum(fg.thresh & (gt > 0))/sum(fg.thresh)  # precision
            recalls[i] <- sum(fg.thresh & (gt > 0))/sum(gt > 0)    # recall
            setTxtProgressBar(pb, value = length(thresh) * (index - 1) + i)
        }
        f1s <- 2 * precs * recalls / (precs + recalls)  # F1-measure
        
        best_thresh <- thresh[which.max(f1s)]
        
        # # Now load the testing data and calculate precision, recall, F1
        # video <- grayscale(load.video(f$video[testIndex], fps = 2))
        # gt <- grayscale(load.video(f$gt[testIndex], fps = 2))
        # bgpath <- paste0('./output/BMC/', methodname, '/bg-', names(f$video)[testIndex], '.mp4')
        # bg <- grayscale(load.video(bgpath, fps = 2))
        # fg <- abs(video - bg)
        # fg.thresh <- (fg > best_thresh)
        # prec <- sum(fg.thresh & (gt > 0))/sum(fg.thresh)  # precision
        # recall <- sum(fg.thresh & (gt > 0))/sum(gt > 0)    # recall
        # f1 <- 2 * prec * recall / (prec + recall)  # F1-measure
        
        # dflist[[index]] <- data.frame(
        #     "video" = names(f$video)[c(trainIndex, testIndex)],
        #     "methodname" = rep(methodname, 2),
        #     "precision" = c(precs[which.max(f1s)], prec),
        #     "recall" = c(recall[which.max(recalls)], recall),
        #     "F1" = c(max(f1s), f1)
        # )
        dflist[[index]] <- data.frame(
            "video" = names(f$video)[trainIndex],
            "methodname" = methodname,
            "precision" = precs[which.max(f1s)],
            "recall" = recalls[which.max(f1s)],
            "F1" = max(f1s),
            "best_threshold" = best_thresh
        )
        
    }
    
    close(pb)
    
    return(do.call(rbind, dflist))
}


{
    methodname <- "VB"
    df <- get.measures(methodname)
    outpath <- paste0('./output/BMC/', methodname, '/', methodname, '.csv')
    write_csv(df, outpath)
}


####################################
library(readr)
library(dplyr)
library(xtable)
library(reshape2)
library(tidyr)

methodnames <- c("svd", "rpca", "ALM", "SRPCP", "VB", "OP", "GoDec", "grasta", "rsvddpd")

dflist <- list()
for (i in 1:length(methodnames)) {
    m <- methodnames[[i]]
    dfpath <- paste0('./output/BMC/', m, '/', m, '.csv')
    df1 <- read_csv(dfpath)
    tspath <- paste0('./output/BMC/', m, '/ts.txt')
    df2 <- read_table(tspath, col_names = c("name", "video", "TimeString"))
    df2 <- df2 %>% mutate(time = as.numeric(substring(TimeString, 6)))
    
    dflist[[i]] <- df1 %>% left_join(df2, by = "video") %>%
        select(video, methodname, Precision = precision, Recall = recall, F1, best_threshold, time)
}
df <- bind_rows(dflist) %>% arrange(methodname, video)

set1 <- c("111", "112", "211", "212", "311", "312", "411", "412", "511", "512")
set2 <- c("121", "122", "221", "222", "321", "322", "421", "422", "521", "522")

for (m in methodnames) {
    cat(paste0("\\multirow{3}{*}{", m, "}\n"))
    measures <- c("Precision", "Recall", "F1")
    for (m2 in measures) {
        subdf <- df %>% filter(methodname == m, video %in% set2)
        cat(paste("&", m2, "&", paste(round(as.numeric(subdf[[m2]]), 3), collapse = " & ")))
        cat("\\\\\n")
    }
    cat("\\midrule\n")
}


df %>% group_by(methodname) %>% 
    summarise(meantime = median(time)/120, sdtime = mad(time/120)) %>%
    xtable()

















