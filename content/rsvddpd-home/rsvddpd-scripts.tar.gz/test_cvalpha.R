library(rsvddpd)
library(dplyr)
library(ggplot2)

# Function to view cv.alpha graph 
alpha_test <- function(type = "uniform", seed = 1234, B = 50){
    set.seed(1234)
    out_val <- seq(1, 25, by = 0.5)
    out_alpha <- matrix(NA, nrow = length(out_val), ncol = B) 
    pb <- txtProgressBar(max = B * length(out_val), style = 3)
    for (i in seq_along(out_val)) {
        for (b in 1:B) {
            if (type == "uniform") {
                X <- matrix(runif(25), nrow = 5, ncol = 5)
            } else if (type == "normal") {
                X <- matrix(rnorm(25), nrow = 5, ncol = 5)
            } else if (type == "lognormal") {
                X <- matrix(rlnorm(25), nrow = 5, ncol = 5)
            } else if (type == "exp") {
                X <- matrix(rexp(25), nrow = 5, ncol = 5)
            } else if (type == "cauchy") {
                X <- matrix(rcauchy(25), nrow = 5, ncol = 5)
            } else if (type == "logis") {
                X <- matrix(rlogis(25), nrow = 5, ncol = 5)
            }
            X[1, 1] <- out_val[i]
            invisible(capture.output(res <- cv.alpha(X, alphas = 49)))
            out_alpha[i, b] <- res$opt.alpha

            setTxtProgressBar(pb, value = (i-1)*B + b)  # set progress bar
        }
    }
    close(pb)
    
    return( tibble("out" = rep(out_val, B), "alpha" = as.vector(out_alpha), "type" = type ) )
}

out_unif <- alpha_test(B = 100, seed = 2021)
out_norm <- alpha_test(type = "normal", B = 100, seed = 2021)
out_lnorm <- alpha_test(type = "lognormal", B = 100, seed = 2021)
out_exp <- alpha_test(type = "exp", B = 100, seed = 2021)
out_cauchy <- alpha_test(type = "cauchy", B = 100, seed = 2021)
out_logis <- alpha_test(type = "logis", B = 100, seed = 2021)

outdf <- bind_rows(out_unif, out_norm, out_lnorm, out_exp, out_cauchy, out_logis)
outdf <- bind_rows(out_unif, out_norm, out_cauchy)
outdf %>% 
    ggplot(aes(x = out, y = alpha, color = type)) + 
    geom_smooth(method = "loess", se = FALSE) +
    theme_bw()

saveRDS(outdf, 'out_alpha.Rds')








