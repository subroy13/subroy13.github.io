#######################
# LOAD REQUIRED PACKAGES
library(imager)
library(rsvddpd)
library(rpca)

# Source Other methods
source('./scripts/rpca_VB.R')
source('./scripts/GoDec.R')
source('./scripts/rpca_ALM.R')
source('./scripts/rpca_OP.R')

frames_to_matrix <- function(images, channel_index = 1) {
    shapes <- dim(images[[1]])
    
    # convert each image into a column
    M <- matrix(0, nrow = shapes[1] * shapes[2], ncol = length(images))
    
    for (i in 1:length(images)) {
        tmp <- channel(images[[i]], channel_index)
        M[, i] <- as.numeric(tmp)
    }
    return(M)
}

matrix_to_frame <- function(M, fr, shapes, savepath = NULL, type = "bg") {
    tmp <- array(dim = c(shapes[1], shapes[2], 1, 3))
    tmp[,,1,1] <- M[[1]][[type]][, fr]
    tmp[,,1,2] <- M[[2]][[type]][, fr]
    tmp[,,1,3] <- M[[3]][[type]][, fr]
    tmp <- as.cimg(tmp)
    if (!is.null(savepath)) {
        save.image(tmp, savepath)
    }
    plot(tmp)
}

#######################################
# UHCTD Data

path <- './data/UHCTD/Stream1_images/'
imageList <- paste0(path, list.files(path))
images <- lapply(imageList, load.image)
images <- lapply(images, imsub, x > 40 & x < 280)

M <- list(frames_to_matrix(images, channel_index = 1), 
          frames_to_matrix(images, channel_index = 2), 
          frames_to_matrix(images, channel_index = 3))
dim(M[[1]])

################################
# Apply Any BG Model Algorithm

# SVD 
methodname <- "svd"

bg.model <- function(methodname) {
    if (methodname == "svd") {
        res <- lapply(1:3, FUN = function(i) {
            y <- svd(M[[i]], nu = 2, nv = 2)
            Mhat <-  y$u[, 1:2] %*% diag(y$d[1:2]) %*% t(y$v[, 1:2])
            return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
        })
    } else if (methodname == "rsvddpd2") {
        alphas <- c(0.6, 0.3, 1)
        res <- lapply(1:3, FUN = function(i) {
            y <- rSVDdpd(M[[i]], nd = 2, alpha = alphas[[i]])
            Mhat <- y$u[, 1:2] %*% diag(y$d[1:2]) %*% t(y$v[, 1:2])
            return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
        })
    } else if (methodname == "rsvddpd") {
        alphas <- c(0.6, 0.3, 1)
        res <- lapply(1:3, FUN = function(i) {
            y <- rSVDdpd(M[[i]], nd = 1, alpha = alphas[[i]])
            Mhat <- y$d[1] * y$u[, 1] %*% t(y$v[, 1])
            return(list("bg" = Mhat, "fg" = M[[i]] - Mhat))
        })
    } else if (methodname == "rpca") {
        res <- lapply(1:3, FUN = function(i) {
            out <- rpca(M[[i]])
            return(list("bg" = out$L, "fg" = M[[i]] - out$L))
        })
    } else if (methodname == "GoDec") {
        res <- lapply(1:3, FUN = function(i) {
            out <- GoDec(M[[i]])
            return(list("bg" = out$LR, "fg" = M[[i]] - out$LR))
        })
    } else if (methodname == "ALM") {
        res <- lapply(1:3, FUN = function(i) {
            out <- ALM(M[[i]])
            return(list("bg" = out$LR, "fg" = M[[i]] - out$LR))
        })
    } else if (methodname == "VB") {
        res <- lapply(1:3, FUN = function(i) {
            out <- VB(M[[i]])
            return(list("bg" = out$LR, "fg" = M[[i]] - out$LR))
        })
    } else if (methodname == "OP") {
        res <- lapply(1:3, FUN = function(i) {
            out <- OP(M[[i]])
            return(list("bg" = out$LR, "fg" = M[[i]] - out$LR))
        })
    } else if (methodname == "GRASTA") {
        res <- lapply(1:3, FUN = function(i) {
            out <- grasta(M[[i]])
            return(list("bg" = out$LR, "fg" = M[[i]] - out$LR))
        })
    }
    return(res)
}

methodname <- "svd"

matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "bg", savepath = paste0('output/UHCTD/stream1/',methodname,'bg_frame5.jpg'))
matrix_to_frame(res, 5, shapes = dim(images[[1]]), type = "fg", savepath = paste0('output/UHCTD/stream1/',methodname,'fg_frame5.jpg'))
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "bg", savepath = paste0('output/UHCTD/stream1/',methodname,'bg_frame50.jpg'))
matrix_to_frame(res, 50, shapes = dim(images[[1]]), type = "fg", savepath = paste0('output/UHCTD/stream1/',methodname,'fg_frame50.jpg'))
matrix_to_frame(res, 75, shapes = dim(images[[1]]), type = "bg", savepath = paste0('output/UHCTD/stream1/',methodname,'bg_frame75.jpg'))
matrix_to_frame(res, 75, shapes = dim(images[[1]]), type = "fg", savepath = paste0('output/UHCTD/stream1/',methodname,'fg_frame75.jpg'))











