# Some Robust Video Surveillancing Method
library(imager)
library(rsvddpd)
library(rpca)


bg.model.rsvddpd <- function(frames) {
  
  convert_matrix_to_frame <- function(M, shapes) {
    img_w <- shapes[1]
    img_h <- shapes[2]
    img_d <- ncol(M)
    stopifnot(nrow(M) == img_w * img_h)
    dim(M) <- c(img_w, img_h, img_d, 1)
    return(as.cimg(M))
  }
  
  
  frames.bw <- grayscale(frames)
  
  # convert frame to Matrix
  shapes <- dim(frames.bw)
  M <- as.numeric(frames.bw)
  dim(M) <- c(shapes[1] * shapes[2], shapes[3])
  
  # Now we perform the robust SVD
  ts <- system.time({
    suppressWarnings({
      out <- rSVDdpd(M, 0.5, nd = 1)
    })
  }) 

  L <- out$d[1] * out$u[, 1] %*% t(out$v[, 1])  # the low rank component
  E <- M - L   # the error foreground model
  E.th <- threshold(E)
  
  # convert both all components into cimg
  return(list(
    "Video" = convert_matrix_to_frame(M, shapes),
    "Background" = convert_matrix_to_frame(L, shapes),
    "Foreground" = convert_matrix_to_frame(E, shapes),
    "Mask" = convert_matrix_to_frame(E.th, shapes),
    "Time" = ts
  ))

}


bg.model.rpca <- function(frames) {
  
  convert_matrix_to_frame <- function(M, shapes) {
    img_w <- shapes[1]
    img_h <- shapes[2]
    img_d <- ncol(M)
    stopifnot(nrow(M) == img_w * img_h)
    dim(M) <- c(img_w, img_h, img_d, 1)
    return(as.cimg(M))
  }
  
  frames.bw <- grayscale(frames)
  
  # convert frame to Matrix
  shapes <- dim(frames.bw)
  M <- as.numeric(frames.bw)
  dim(M) <- c(shapes[1] * shapes[2], shapes[3])
  
  # Now we perform the robust SVD
  ts <- system.time({
    suppressWarnings({
      out <- rpca(M)
    })
  }) 

  L <- out$L  # the low rank component
  E <- M - L   # the error foreground model
  E.th <- threshold(E)
  
  # convert both all components into cimg
  return(list(
    "Video" = convert_matrix_to_frame(M, shapes),
    "Background" = convert_matrix_to_frame(L, shapes),
    "Foreground" = convert_matrix_to_frame(E, shapes),
    "Mask" = convert_matrix_to_frame(E.th, shapes),
    "Time" = ts
  ))

}
