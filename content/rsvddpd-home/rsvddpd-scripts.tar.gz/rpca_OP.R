# Robust PCA using Outlier Pursuit
# Source: H. Xu, C. Caramanis, S. Sanghavi, “Robust PCA via Outlier Pursuit”, International Conference on Neural Information Processing System, NIPS 2010, 2010.
# Input:
# % This is a function to solve mr_PCA with partial observation
# % X is the input matrix with partical observation
# % Omega is the sampling set, i.e., Omega_(i,j)=1 if X_i,j is observed
# % lambda is the input paremter
# % L is the output low rank matrix
# % C is the output column sparse matrix

rpca_OP <- function(X, Omega = NA, lambda = NA, tol = 1e-6, maxiter = 100) {
    m <- nrow(X)
    n <- ncol(X)
    if (is.na(Omega)) {
        Omega <- matrix(1, nrow = m, ncol = n)  # everything is observed
    }
    if (is.na(lambda)) {
        lambda <- 0.5
    }
    # ------------
    # Iteration subroutines    
    iterateL <- function(L, epsilon) {
        svdval <- svd(L)
        svdval$d <- ifelse(
            abs(svdval$d) > epsilon,
            sign(svdval$d)*(abs(svdval$d) - epsilon),
            0
        )
        rank_out <- sum(abs(svdval$d) > 0)
        return(list(
            "L" = svdval$u %*% diag(svdval$d) %*% t(svdval$v),
            "rank_L" = rank_out
        ))

    }


    iterateC <- function(C, epsilon) {
        m <- nrow(C)
        n <- ncol(C)
        for (i in 1:n) {
            temp <- C[, i]
            norm_temp <- sqrt(sum(temp^2))
            if (norm_temp > epsilon) {
                temp <- temp - temp * epsilon/norm_temp
            } else {
                temp <- rep(0, m)
            }
            C[, i] <- temp
        }
        return(C)
    }



    # ------------
    # Initialization
    delta <- 0.00001
    mu_temp <- 0.99 * norm(X) / sqrt(max(m, n))
    mu_bar <- delta * mu_temp
    eta <- 0.9
    stoptol <- tol * norm(X, "F")
    iter <- 0
    stopping <- FALSE

    # L_temp0, C_temp0 is L_k and C_k
    # L_temp1, C_temp1 is L_{k-1} and C_{k-1}
    L_temp0 <- matrix(0, nrow = m, ncol = n)
    L_temp1 <- matrix(0, nrow = m, ncol = n)
    C_temp0 <- matrix(0, nrow = m, ncol = n)
    C_temp1 <- matrix(0, nrow = m, ncol = n)
    t_temp0 <- 1
    t_temp1 <- 1
    k <- 0

    while (!stopping) {
        YL <- L_temp0 + (t_temp1 - 1)/t_temp0 * (L_temp0 - L_temp1)
        YC <- C_temp0 + (t_temp1 - 1)/t_temp0 * (C_temp0 - C_temp1)
        M_diff <- (YL + YC - X) * Omega 
        
        GL <- YL - 0.5 * M_diff
        itL <- iterateL(GL, mu_temp /2)
        L_new <- itL$L; rank_L <- itL$rank_L

        GC <- YC - 0.5 * M_diff
        C_new <- iterateC(GC, mu_temp * lambda / 2)

        t_new <- (1 + sqrt(4 * t_temp0^2 + 1))/2
        mu_new <- max(eta*mu_temp, mu_bar)

        # ---------------
        # Check convergence
        temp <- (L_new + C_new - YL - YC)
        S_L <- 2 * (YL - L_new) + temp
        S_C <- 2 * (YC - C_new) + temp
        err <- norm(S_L, "F")^2 + norm(S_C, "F")^2
        iter <- iter + 1
        if (err < stoptol^2) {
            stopping <- TRUE
        }
        if (iter >= maxiter) {
            stopping <- TRUE
        }
        L_temp1 <- L_temp0
        L_temp0 <- L_new 
        C_temp1 <- C_temp0
        C_temp0 <- C_new 
        t_temp1 <- t_temp0
        t_temp0 <- t_new 
        mu_temp <- mu_new
    }

    return(list(
        "LR" = L_new,
        "Sparse" = C_new,
        "Noise" = (X - L_new - C_new),
        "Iteration" = iter
    ))

}

# m = 10
# n = 5
# r = 2  #rank of the low-rank component
# 
# A = matrix(rnorm(m*r), nrow = m, ncol = r)
# B = matrix(rnorm(n*r), nrow = r, ncol = n)
# X_true = A %*% B # low rank component
# out <- rpca_OP(X_true)



