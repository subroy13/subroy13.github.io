# Variational Bayesian Robust Principal Component Analysis
# Usage:
# (X, A, B, E, varargout) = vbRPCA(Y, options)
# Solve for A, B, E such that, 
# Y = X (low rank) (= AB') + E (sparse) + N (noise)
# Source: 
#    S. D. Babacan, M. Luessi, R. Molina, and A. K. Katsaggelos, 
#    "Sparse Bayesian Methods for Low-Rank Matrix Estimation," 
#    IEEE Transactions on Signal Processing, 2012.


rpca_VB <- function(Y, options = NA) {
    
    # Parameter Initialization part
    if (is.na(options)) {
        init.options <- list(
            "initmethod" = "ml",
            "a_gamma0" = 1e-6,
            "b_gamma0" = 1e-6,
            "a_alpha0" = 0,
            "b_alpha0" = 0,
            "a_beta0" = 0,
            "b_beta0" = 0,
            "maxiter" = 100,
            "dimred" = TRUE,      # whether to prune irrelavant dimension during iterations
            "inf_flag" = 2,     # Inference method for E (1 - Standard, 2 - fixed point MacKay) 
            "update_beta" = TRUE,
            "mode" = "VB",
            "threshold" = 1e-4,
            "initial_rank" = "auto"
        )
    } else {
        init.options <- options
    }

    if (init.options$dimred) {
        dim_threshold <- 1e4
    }

    m <- nrow(Y)
    n <- ncol(Y)
    scale <- sqrt(mean(Y^2))
    eps <- 0

    # Initialize A, B and E for Bayesian MC
    if (init.options$initmethod == "ml") {
        svdval <- svd(Y)
        if (init.options$initial_rank == "auto") {
            r <- min(m,n)
        } else {
            r <- init.options$initial_rank
        }
        A <- svdval$u %*% diag(svdval$d^0.5)
        B <- t(diag(svdval$d^0.5) %*% t(svdval$v))
        gammas <- scale * rep(1, r)
        Sigma_A <- diag(r) * scale 
        Sigma_B <- diag(r) * scale
        beta <- 1 / scale^2
        Sigma_E <- scale * diag(r)
        alphas = matrix(1, nrow = m, ncol = n) * scale

    } else if (init.options$initmethod == "random") {
        r <- min(m,n)
        A <- matrix(rnorm(m*r), nrow = m, ncol = r) * sqrt(scale)
        B <- matrix(rnorm(n*r), nrow = n, ncol = r) * sqrt(scale)
        gammas <- scale * rep(r, 1)
        Sigma_A <- diag(r) * scale 
        Sigma_B <- diag(r) * scale
        beta <- 1 / scale^2
        Sigma_E <- scale * diag(r)
        alphas = matrix(1, nrow = m, ncol = n) * scale
    } else {
        stop("Only ml and random initialization method is available")
    }

    X <-  A %*% t(B)
    E <- Y - X
    for (it in 1:init.options$maxiter) {
        old_X <- X
        old_E <- E 

        # -----------------------
        # update X
        W <- diag(gammas)
        
        # A step
        if (init.options$mode == "VB") {
            Sigma_A <- solve(beta * crossprod(B) + W + beta * n * Sigma_B)
            A <- beta * (Y - E) %*% B %*% Sigma_A
        } else if (init.options$mode == "VB_app") {
            Sigma_A <- (beta * crossprod(B) + W + beta*n*Sigma_B)
            A <- beta * (Y - E) %*% B  %*% solve(Sigma_A)
            Sigma_A <- diag(1/diag(Sigma_A))
        } else if (init.options$mode == "MAP") {
            Sigma_A <- (beta * crossprod(B) + W + beta*n*Sigma_B)
            A <- beta * (Y - E) %*% B %*% solve(Sigma_A)
            Sigma_A <- matrix(0, nrow = nrow(Sigma_A), ncol = ncol(Sigma_A))
        } else {
            stop("Mode not implemented yet!")
        }
        
        # B step
        if (init.options$mode == "VB") {
            Sigma_B <- solve(beta * crossprod(A) + W + beta * m * Sigma_A)
            B <- beta * t(Y - E) %*% A %*% Sigma_B
        } else if (init.options$mode == "VB_app") {
            Sigma_B <- (beta * crossprod(A) + W + beta * m * Sigma_A)
            B <- beta * t(Y - E) %*% A %*% solve(Sigma_B)
            Sigma_B <- diag(1/diag(Sigma_B))
        } else if (init.options$mode == "MAP") {
            Sigma_B <- (beta * crossprod(A) + W + beta * m * Sigma_A)
            B <- beta * t(Y - E) %*% A %*% solve(Sigma_B)
            Sigma_B <- matrix(0, nrow = nrow(Sigma_B), ncol = ncol(Sigma_B))
        } else {
            stop("Mode not implemented yet!")
        }

        X <- A %*% t(B)

        # -----------------------
        # update E
        Sigma_E <- 1/(alphas + beta)
        E <- beta * (Y - X) * Sigma_E

        # -----------------------
        # update alphas
        #   Choose inference method (fixed point Mackay or standard)
        if (init.options$inf_flag == 1) {
            alphas <- 1/(E^2 + Sigma_E)
        } else if (init.options$inf_flag == 2) {
            alphas <- (1 - alphas * Sigma_E + init.options$a_alpha0) / (E^2 + eps + init.options$b_alpha0)
        } else {
            stop("Inference flag should be either 1 or 2")
        }  
        
        # -----------------------
        # update gammas
        #   Choose inference method (fixed point Mackay or standard)
        gammas <- (m + n + init.options$a_gamma0) / (diag(crossprod(B)) + diag(crossprod(A)) + m*diag(Sigma_A) + n * diag(Sigma_B) + init.options$b_gamma0 )

        # ------------------------
        # update beta
        if (init.options$update_beta) {
            err <- sum((Y - X - E)^2) + n*sum(diag(crossprod((A) %*% Sigma_B )) ) + m * sum(diag(crossprod(B) %*% Sigma_A)) + m * n* sum(diag(Sigma_A %*% Sigma_B)) + sum(Sigma_E)
            beta <- (m*n + init.options$a_beta0) / (err + init.options$b_beta0)
        }

        # ----------------------
        # Prune irrelevant dimensions
        if (init.options$dimred) {
            MAX_GAMMA <- min(gammas) * dim_threshold
            if (any(gammas > MAX_GAMMA)) {
                indices <- which(gammas <= MAX_GAMMA)

                A <- A[, indices]
                B <- B[, indices]
                gammas <- gammas[indices]
                Sigma_A <- Sigma_A[indices, indices]
                Sigma_B <- Sigma_B[indices, indices]

                m <- nrow(A)
                r <- ncol(A)
                n <- ncol(t(B))

            }
        }

        # -------------------
        # Check convergence
        Xconv <- norm(old_X - X, "F") / norm(old_X, "F")
        if (is.na(Xconv)) {
            break
        }

        if ((it > 5) & (Xconv < init.options$threshold)) {
            break
        }
        
    }

    output <- list(
        "LR" = X,
        "A" = A,
        "B" = B,
        "Sparse" = E, 
        "Noise" = (Y - X - E)
    )

    return(output)

}


# # Given test
# # Create a low-rank + sparse matrix # Dimensions
# m = 100
# n = 50
# r = 10  #rank of the low-rank component
# 
# A = matrix(rnorm(m*r), nrow = m, ncol = r)
# B = matrix(rnorm(n*r), nrow = r, ncol = n)
# X_true = A %*% B # low rank component
# 
# SparseRatio = 0.05
# E_true = matrix(0, nrow = nrow(X_true), ncol = ncol(X_true))
# Eomega = sample(m*n, round(m*n*SparseRatio))
# E_true[Eomega] = -10+20*rep(1, length(Eomega)) # sparse component
# 
# Y = X_true + E_true
# out <- vbRPCA(Y) 
# out <- vbRPCA(X_true)






























