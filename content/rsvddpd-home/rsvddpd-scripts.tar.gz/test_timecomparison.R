library(microbenchmark)
library(RobRSVD)
library(pcaMethods)
library(rsvddpd)

set.seed(12345)
p <- 25
n <- 1000   # change as required
X <- matrix(runif(n * p), nrow = n, ncol = p)

# svd and pcaSVD requires division by rank to estimate time for one singular value
y1 <- microbenchmark(svd(X), 
                    { suppressWarnings( try(robustSvd(X), silent = T)) }, times = 25) 
y1$time <- y1$time / min(n, p)


# RobSVD and RobRSVD
y2 <- microbenchmark( RobRSVD(X, irobust = T, iugcv = F, ivgcv = F),
                      RobRSVD(X, irobust = T, iugcv = T, ivgcv = T), times = 1)

# rSVDdpd
y3 <- microbenchmark( { suppressWarnings(rSVDdpd(X, alpha = 0.1, nd = 1)) },
                      { suppressWarnings(rSVDdpd(X, alpha = 0.5, nd = 1)) },
                      { suppressWarnings(rSVDdpd(X, alpha = 1, nd = 1)) }, times = 25)


y <- print(bind_rows(y1, y2, y3), "ms")
cat(paste(c(n, round(y$median, 3)), collapse = " & "))






