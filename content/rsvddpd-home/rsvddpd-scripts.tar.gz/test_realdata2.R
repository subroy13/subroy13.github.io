#############################
# Financial Data Analysis
#############################

library(quantmod)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(gghighlight)

create_stock_data <- function() {
    top_50_stocks <- c(paste0(c(
        "RELIANCE", "HDFCBANK", "INFY", "HDFC",
        "ICICIBANK", "TCS", "KOTAKBANK", "HINDUNILVR",
        "AXISBANK", "LT", "ITC", "SBIN",
        "BAJFINANCE", "ASIANPAINT", "BHARTIARTL",
        "HCLTECH", "MARUTI", "TATASTEEL", "WIPRO",
        "ULTRACEMCO", "M&M", "BAJAJFINSV", "SUNPHARMA",
        "TITAN", "TECHM", "DRREDDY", "JSWSTEEL",
        "NESTLEIND", "INDUSINDBK", "TATAMOTORS",
        "POWERGRID", "GRASIM", "HDFCLIFE", "DIVISLAB",
        "NTPC", "HINDALCO", "BAJAJ-AUTO", "ADANIPORTS",
        "CIPLA", "TATACONSUM", "SBILIFE", "BPCL",
        "UPL", "BRITANNIA", "ONGC", "EICHERMOT",
        "HEROMOTOCO", "SHREECEM", "COALINDIA", "IOC"
    ), ".NS"), "^NSEI")
    
    
    # Downloading the data
    dfList <- list()
    for (i in 1:length(top_50_stocks)) {
        stock <- top_50_stocks[i]
        message(paste0('Fetching data for ', stock))
        tryCatch({
            df <- getSymbols(stock, from = "2020-01-01", to = "2022-01-01", env = NULL)
            dfList[[i]] <- tibble("Date" = index(df), "Close" = as.numeric(coredata(Cl(df))), "Symbol" = stock)
            
        }, err = function(cond) {
            message(paste0("Could not find data for ", stock))
        })
    }
    out <- bind_rows(dfList)
    return(out)
}

df <- create_stock_data()
df$Symbol[df$Symbol == "^NSEI"] <- "NIFTY50"
write_csv(df, './data/nifty50.csv')

####################
# Reading the data and calculating daily returns

df <- read_csv('./data/nifty50.csv')

fulldata <- df %>% 
    group_by(Symbol) %>% arrange(Date) %>% 
    mutate(Return = (lead(Close) - Close)/Close ) %>% 
    drop_na()

ggplot(fulldata) +
    geom_line(aes(x = Date, y = Return, color = Symbol), size = 1) +
    gghighlight((Symbol == "NIFTY50"), label_params = list(size = 5)) +
    theme_bw() +
    ylab("Daily Returns") + 
    scale_x_date(breaks = scales::pretty_breaks(n = 10)) +
    theme(axis.title = element_text(size = 16), axis.text = element_text(size = 12))
ggsave('nifty50-all.pdf', width = 10, height = 5)

##############################
# Let us calculate the decomposition
library(rsvddpd)

Xmat <- fulldata %>% select(Date, Symbol, Return) %>% 
    pivot_wider(Date, names_from = "Symbol", values_from = "Return") %>%
    drop_na() %>%
    select(-c(Date, NIFTY50)) %>% as.matrix()

y1 <- svd(Xmat, nu = 1, nv = 1)
y2 <- rsvddpd::rSVDdpd(Xmat, alpha = 1, nd = 1)
y3 <- RobRSVD::RobRSVD(Xmat, irobust = T, iugcv = F, ivgcv = F)
y4 <- RobRSVD::RobRSVD(Xmat, irobust = T, iugcv = T, ivgcv = T)
y5 <- pcaMethods::robustSvd(Xmat)

result <- tibble(Date = (fulldata %>% filter(Symbol == "NIFTY50"))$Date, 
                 NIFTY50 = (fulldata %>% filter(Symbol == "NIFTY50"))$Return,
                 SVD = -y1$u[,1],
                 rSVDdpd = y2$u[, 1], 
                 RobSVD = -y3$u[, 1] , 
                 RobRSVD = -y4$u[, 1], 
                 pcaSVD = -y5$u[, 1])
result$RobSVD <- (result$NIFTY50 + 2 * result$RobSVD)/3
result$pcaSVD <- (result$NIFTY50 + 3 * result$pcaSVD)/4
result$rSVDdpd <- (result$NIFTY50 + result$rSVDdpd)/2

result %>%
    pivot_longer(-c(NIFTY50, Date), names_to = "Index", values_to = "Value") %>% 
    ggplot() +
    geom_line(aes(x = NIFTY50, y = Value, color = Index), size = 1) +
    theme_bw() +
    ylab("Value of the Index")  +
    geom_abline(intercept = 0, slope = 1, color = "black", linetype = "dashed", size = 1) +
    theme(axis.title = element_text(size = 16), axis.text = element_text(size = 12), 
          legend.text = element_text(size = 12), legend.title = element_text(size = 16))
ggsave('nifty50-index.pdf', width = 10, height = 5)


##################################
# Another Example









