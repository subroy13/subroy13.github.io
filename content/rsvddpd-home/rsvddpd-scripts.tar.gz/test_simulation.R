# True Matrix Generation
U <- as.matrix(poly(1:10, degree = 3))
V <- as.matrix(poly(1:4, degree = 3))
X <- U %*% diag(c(10, 5, 3)) %*% t(V)
B <- 5000  # Use 5000 resamples

#######################
# Obtain Simulation matrices and store them

# Simulation S1
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))        
    samples[,,i] <- X + errors
}
saveRDS(samples, './simulation_results/S1_samples.Rds')


# Simulation S2a
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    ind <- matrix(rbinom(nrow(X) * ncol(X), size = 1, prob = 0.05), nrow = nrow(X), ncol = ncol(X))
    samples[,,i] <- X + (1 - ind) * errors + ind * 25
}
saveRDS(samples, './simulation_results/S2a_samples.Rds')


# Simulation S2b
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    ind <- matrix(rbinom(nrow(X) * ncol(X), size = 1, prob = 0.1), nrow = nrow(X), ncol = ncol(X))
    samples[,,i] <- X + (1 - ind) * errors + ind * 25
}
saveRDS(samples, './simulation_results/S2b_samples.Rds')


# Simulation S2c
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    ind <- matrix(rbinom(nrow(X) * ncol(X), size = 1, prob = 0.2), nrow = nrow(X), ncol = ncol(X))
    samples[,,i] <- X + (1 - ind) * errors + ind * 25
}
saveRDS(samples, './simulation_results/S2c_samples.Rds')


# Simulation S2d
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    ind <- matrix(rbinom(nrow(X) * ncol(X), size = 1, prob = 0.15), nrow = nrow(X), ncol = ncol(X))
    samples[,,i] <- X + (1 - ind) * errors + ind * 25
}
saveRDS(samples, './simulation_results/S2d_samples.Rds')



# Simulation S3
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    sample_row <- sample(nrow(X), size = 1)
    errors[sample_row, ] <- 0 
    tmp <- numeric(nrow(X))
    tmp[sample_row] <- 25
    outliers <- matrix(tmp, nrow = nrow(X), ncol = ncol(X))
    samples[,,i] <- X + errors + outliers
}
saveRDS(samples, './simulation_results/S3_samples.Rds')


# Simulation S4
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rcauchy(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))        
    samples[,,i] <- X + errors
}
saveRDS(samples, './simulation_results/S4_samples.Rds')


# Simulation S5
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rlnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))        
    samples[,,i] <- X + errors
}
saveRDS(samples, './simulation_results/S5_samples.Rds')

# Simulation S6
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    rowind <- sample(nrow(X) - 2, size = 1)
    colind <- sample(ncol(X) - 2, size = 1)
    samples[,,i] <- X + errors
    samples[rowind:(rowind + 2),colind:(colind + 2),i] <- 25
}
saveRDS(samples, './simulation_results/S6_samples.Rds')


# Simulation S7
set.seed(12345)
samples <- array(NA, dim = c(dim(X), B))
for (i in 1:B) {
    errors <- matrix(rnorm(nrow(X) * ncol(X)), nrow = nrow(X), ncol = ncol(X))
    rowind <- sample(nrow(X) - 1, size = 1)
    colind <- sample(ncol(X) - 1, size = 1)
    ind <- matrix(0, nrow = nrow(X), ncol = ncol(X))
    ind[rowind:(rowind + 1),colind:(colind + 1)] <- 1
    samples[,,i] <- X + errors * (1 - ind) + 25 * ind
}
saveRDS(samples, './simulation_results/S7_samples.Rds')



#########################################################################
# Final Simulation and Compare Results

library(rsvddpd)
library(RobRSVD)
library(pcaMethods)
library(pbapply)

# Zhang's Robust RSVD (with Robust loss and Penalty)
# modified to output all singular values and vectors
robrsvd <- function(X, irobust = T, iugcv = T, ivgcv = T) {
    n <- nrow(X)
    p <- ncol(X)
    r <- min(n, p)
    
    d <- numeric(r)
    u <- matrix(NA, nrow = n, ncol = r)
    v <- matrix(NA, nrow = p, ncol = r)
    
    for (k in 1:r) {
        tmp <- RobRSVD::RobRSVD(X, irobust = irobust, iugcv = iugcv, ivgcv = ivgcv)
        d[k] <- tmp$s
        u[,k] <- tmp$u[, 1]
        v[,k] <- tmp$v[, 1]
        X <- X - d[k] * (u[, k] %*% t(v[, k]))
    }
    return(list(d = d, u = u, v = v))
}

# Use parallelism 
simsetup <- "S2d"   # change the name of simulation setup here
B <- 5000

samples <- readRDS(paste0('./simulation_results/',simsetup,'_samples.Rds', sep = ""))
dim(samples)
ncores <- parallel::detectCores() - 1
cl <- makeCluster(ncores)
clusterExport(cl, c("robrsvd", "samples"))

# performs SVDs on multicore
out_svd <- pblapply(1:B, FUN = function(x) { svd(samples[,,x]) }, cl = cl)
out_pcasvd <- pblapply(1:B, FUN = function(x) { try(pcaMethods::robustSvd(samples[,,x])) }, cl = cl)
out_RobRSVD <- pblapply(1:B, FUN = function(x) { try(robrsvd(samples[,,x])) }, cl = cl)
out_RobRSVD_nopenalty <- pblapply(1:B, FUN = function(x) { try(robrsvd(samples[,,x], irobust = T, iugcv = F, ivgcv = F)) }, cl = cl)
out_rsvddpd_0 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 0))) }, cl = cl)
out_rsvddpd_1 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 0.1))) }, cl = cl)
out_rsvddpd_2 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 0.3))) }, cl = cl)
out_rsvddpd_3 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 0.5))) }, cl = cl)
out_rsvddpd_4 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 0.7))) }, cl = cl)
out_rsvddpd_5 <- pblapply(1:B, FUN = function(x) { try(suppressWarnings(rsvddpd::rSVDdpd(samples[,,x], alpha = 1))) }, cl = cl)

out <- list(
    "svd" = out_svd,
    "pcasvd" = out_pcasvd,
    "RobRSVD" = out_RobRSVD,
    "RobRSVD_nopenalty" = out_RobRSVD_nopenalty,
    "rSVDdpd_0" = out_rsvddpd_0, "rSVDdpd_0.1" = out_rsvddpd_1,
    "rSVDdpd_0.3" = out_rsvddpd_2, "rSVDdpd_0.5" = out_rsvddpd_3,
    "rSVDdpd_0.7" = out_rsvddpd_4, "rSVDdpd_1" = out_rsvddpd_5
)

saveRDS(out, paste0('./simulation_results/',simsetup,'_results.Rds'))

stopCluster(cl)



#######################################
# Create summaries 

make_summary <- function(simsetup) {
    # true parameters
    U <- as.matrix(poly(1:10, degree = 3))
    V <- as.matrix(poly(1:4, degree = 3))
    
    samples <- readRDS(paste0('./simulation_results/',simsetup,'_samples.Rds'))
    out <- readRDS(paste0('./simulation_results/',simsetup,'_results.Rds'))
    
    # calculates singular value bounds
    bounds <- sapply(1:B, FUN = function(i) { norm(samples[,,i], type = "1") * norm(samples[,,i], type = "I") } )
    bounds <- sqrt(bounds)
    
    procs <- c("svd", "pcasvd", "RobRSVD_nopenalty", "RobRSVD", "rSVDdpd_0", "rSVDdpd_0.1", "rSVDdpd_0.3", "rSVDdpd_0.5", "rSVDdpd_0.7", "rSVDdpd_1")
    
    convg <- matrix(FALSE, nrow = B, ncol = length(procs))
    colnames(convg) <- procs
    for (proc in procs) {
        convg[, proc] <- sapply(1:B, FUN = function(i) {
            is.list(out[[proc]][[i]]) && (!any(is.na(out[[proc]][[i]]$d))) && (out[[proc]][[i]]$d[1] <= bounds[i]) && (out[[proc]][[i]]$d[1] <= 1e5)
        })
    }
    
    good_index <- sapply(1:B, FUN = function(i) { all(convg[i, ]) } )   # index where all of them converges
    
    # Bias, MSE calculations
    biases <- matrix(NA, nrow = 4, ncol = length(procs))
    mse <- matrix(NA, nrow = 4, ncol = length(procs))
    lscores <- matrix(NA, nrow = 3, ncol = length(procs))
    rscores <- matrix(NA, nrow = 3, ncol = length(procs))
    colnames(biases) <- colnames(mse) <- colnames(lscores) <- colnames(rscores) <- procs
    
    for (proc in procs) {
        svals <- matrix(NA, nrow = B, ncol = 4)
        lvecs <- matrix(NA, nrow = B, ncol = 3)
        rvecs <- matrix(NA, nrow = B, ncol = 3)
        for (i in 1:B) {
            if (good_index[i]) {
                svals[i, ] <- out[[proc]][[i]]$d - c(10, 5, 3, 0)   # calculates the residuals
                lvecs[i, ] <- colSums(out[[proc]][[i]]$u[, 1:3] * U)
                rvecs[i, ] <- colSums(out[[proc]][[i]]$v[, 1:3] * V)
            }
        }
        
        biases[, proc] <- colMeans(svals[good_index, ])
        mse[, proc] <- colMeans(svals[good_index, ]^2)
        lscores[, proc] <- colMeans(1 - abs(lvecs[good_index, ]))
        rscores[, proc] <- colMeans(1 - abs(rvecs[good_index, ]))
    }
    
    # Obtain total scores
    biases <- rbind(biases, colSums(biases^2))
    mse <- rbind(mse, colSums(mse))
    lscores <- rbind(lscores, colSums(lscores))
    rscores <- rbind(rscores, colSums(rscores))
    
    # Output the number of resamples used
    message(paste0('The number of resamples used: ', sum(good_index)))
    
    return(list("Bias" = round(biases,3), "MSE" = round(mse,3), 
                "Left" = round(lscores,3), "Right" = round(rscores,3) ))
}

# Formatting to Latex Code
format_result <- function(res) {
    method_names <- c("Usual SVD", "pcaSVD", "RobSVD", "RobRSVD", "$\\alpha = 0$", "$\\alpha = 0.1$", 
                      "$\\alpha = 0.3$", "$\\alpha = 0.5$", "$\\alpha = 0.7$", "$\\alpha = 1$")
    
    method_names <- paste0("\\multirow{2}{*}{", method_names, "}")
    
    tab1_code <- ""
    tab2_code <- ""
    for (i in 1:length(method_names)) {
        l1 <- paste(method_names[i], "& Bias &", paste(res$Bias[, i], collapse = " & "), "\\\\")
        l2 <- paste("& MSE &", paste(res$MSE[, i], collapse = " & "), "\\\\ \\midrule")
        tab1_code <- paste(tab1_code, l1, l2)
        
        l3 <- paste(method_names[i], "& Left &", paste(res$Left[, i], collapse = " & "), "\\\\")
        l4 <- paste("& Right &", paste(res$Right[, i], collapse = " & "), "\\\\ \\midrule")
        tab2_code <- paste(tab2_code, l3, l4)
    }
    
    cat(tab1_code)
    cat("\n\n\n")
    cat(tab2_code)
}


simsetup <- "S5"
B <- 5000
res <- make_summary(simsetup)
format_result(res)

cat(paste(
    "Bias & ", paste(res$Bias[5, -5], collapse = " & "), "\\\\ ",
    "& MSE & ", paste(res$MSE[5, -5], collapse = " & "), "\\\\ ",
    "& Diss (left) & ", paste(res$Left[4, -5], collapse = " & "), "\\\\ ",
    "& Diss (right) & ", paste(res$Right[4, -5], collapse = " & "), "\\\\ \\midrule"
))














