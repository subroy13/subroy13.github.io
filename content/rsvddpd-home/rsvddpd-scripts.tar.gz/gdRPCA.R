# Robust PCA via Non-convex Gradient Descent
# % Y : A sparse matrix to be decomposed into a low-rank matrix M and a sparse
# % matrix S. Unobserved entries are represented as zeros.
# % r : Target rank
# % alpha : An upper bound of max sparsity over the columns/rows of S
# % params : parameters for the algorithm
# %   .step_const : Constant for step size (default .5)
# %   .max_iter : Maximum number of iterations (default 30)
# %   .tol : Desired Frobenius norm error (default 2e-4)
# %   .incoh : Incoherence of M (default 5)
# %
# % Output:
# % U, V : M=U*V' is the estimated lowrank matrix
# %
# % By:
# % Xinyang Yi, Dohyung Park, Yudong Chen, Constantine Caramanis
# % {yixy,dhpark,constantine}@utexas.edu, yudong.chen@cornell.edu

gdRPCA <- function(Y, r = NA, alpha = 0.5, params = NA) {
    d1 <- nrow(Y)
    d2 <- ncol(Y)
    if (is.na(r)) {
        r <- min(d1, d2)
    }
    if (is.na(params)) {
        params <- list(
            "step_const" = 0.5,
            "max_iter" = 30,
            "tol" = 2e-4,
            "do_project" = FALSE,
            "gamma" = 1,
            "incoh" = 5
        )
    }

    # -----------------
    # Phase I: Initialization
    Ynorm <- norm(Y, "F")
    alpha_col <- alpha 
    alpha_row <- alpha 
    p <- 1
    
    # initial projection
    S <- Tproj_partial(Y, params$gamma * p * alpha_col, params$gamma * p * alpha_row)

    # initial factorization
    svdinit <- svd((Y - S)/p, nu = r, nv = r)
    U <- svdinit$u[, 1:r] %*% diag(svdinit$d[1:r]^0.5)
    V <- svdinit$v[, 1:r] %*% diag(svdinit$d[1:r]^0.5)

    # projection
    if (params$do_project) {
        const1 <- sqrt(4 * params$incoh * r / d1) * svdinit$d[1]
        const2 <- sqrt(4 * params$incoh * r / d2) * svdinit$d[1]
        v1 <- pmin(rep(1, d1), const1 / sqrt(colSums(U^2)))
        v2 <- pmin(rep(1, d2), const2 / sqrt(colSums(V^2)))
        U <- U * matrix(v1, nrow = d1, ncol = r, byrow = FALSE)
        V <- V * matrix(v2, nrow = d2, ncol = r, byrow = FALSE)
    }

    # ---------------
    # Phase II : Gradient Descent
    steplength <- params$step_const / svdinit$d[1]
    YminusUV <- matrix(0, nrow = d1, ncol = d2)

    converged <- FALSE
    iter <- 0
    while (!converged) {
        YminusUV <- Y - U %*% t(V)

        # sparse projection for S
        S <- Tproj_partial(YminusUV, params$gamma * p * alpha_col, params$gamma * p * alpha_row)
        E <- YminusUV - S 

        # gradient descent for U and V
        crossdiff <- (crossprod(U) - crossprod(V))
        Unew <- U + steplength * (E %*% V) / p - steplength/16 * U %*% crossdiff
        Vnew <- V + steplength * t((t(U) %*% E)) / p - steplength/16 * V %*% (-crossdiff)

        # projection
        if (params$do_project) {
            v1 <- pmin(rep(1, d1), const1 / sqrt(colSums(Unew^2)))
            v2 <- pmin(rep(1, d2), const2 / sqrt(colSums(Vnew^2)))
            Unew <- Unew * matrix(v1, nrow = d1, ncol = r, byrow = FALSE)
            Vnew <- Vnew * matrix(v2, nrow = d2, ncol = r, byrow = FALSE)
        }

        U <- Unew 
        V <- Vnew 

        err <- norm(E, "F")/Ynorm
        iter <- iter + 1
        if (iter >= params$max_iter) {
            converged <- TRUE
        }
        if (err < params$tol) {
            converged <- TRUE
        }
    }

    return(list(
        "LR" = U %*% t(V),
        "U" = U,
        "V" = V,
        "Sparse" = S, 
        "Noise" = E 
    ))

}


Tproj_partial <- function(S, a_col, a_row) {
    # performs thresholding to obtain sparse projection of S

    d1 <- nrow(S)
    d2 <- ncol(S)
    kcol <- floor(a_col * d1)
    krow <- floor(a_row * d2)
    if (kcol * krow == 0) {
        return(S * 0)
    } 
    threshold <- sort(-abs(S), partial = kcol * krow)
    threshold <- min(-threshold[kcol * krow])
    S[abs(S) < threshold] <- 0
    return(S)
}



