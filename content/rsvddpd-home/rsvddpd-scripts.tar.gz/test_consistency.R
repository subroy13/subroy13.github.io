library(matrixStats)
library(rsvddpd)
library(parallel)
library(pbapply)
library(pracma)
library(ggplot2)

# The basic theme for all the plots
theme_custom <- function(...) {
    theme_bw() +
        theme(
            axis.title = element_text(size = 14),
            axis.text.y = element_text(size = 11),
            axis.text.x = element_text(size = 11, angle = 90),
            legend.title = element_text(size = 16),
            legend.text = element_text(size = 12),
            legend.spacing = unit(5.0, 'cm'),
            plot.margin = unit(c(0.75,0.75,0.75,0.75), "cm")
        )
}


sim.X <- function(n, seed = 1234) {
    set.seed(seed)
    eigenvals <- c(10, 5, 3)
    eigenvecs <- randortho(n)[, 1:5]
    
    X <- eigenvecs[, c(2, 3, 1)] %*% diag(eigenvals) %*% t(eigenvecs[, c(5, 3, 4)])
    X <- X + matrix(rnorm(n * n, 0, sd = 1/sqrt(n)), nrow = n)
    return(X)
}

# Generate n x n random matrices
getSVDMetric <- function(n, B = 100, robust = FALSE) {
    seeds <- sample(1:100000, size = B, replace = F)
    cl <- makeCluster(parallel::detectCores() - 1)
    clusterExport(cl, c("sim.X", "rSVDdpd", "randortho"))
    
    outputs <- pbsapply(1:B, FUN = function(b) {
        X <- sim.X(n, seed = seeds[b])
        if (robust) {
            sout <- rSVDdpd(X, 0.5, nd = 1)
        } else{
            sout <- svd(X, nu = 1, nv = 1)
        }
        return(sout$d[1])
    }, cl = cl)
    closeAllConnections()
    
    return(
        list(
            "elist" = outputs,
            "bias" = mean(outputs - 10),
            "rmse" = sqrt(mean((outputs - 10)^2))
        )
    )
}

##########################
# Usual SVD

aout <- list(
    "10" = getSVDMetric(10),
    "25" = getSVDMetric(25),
    "50" = getSVDMetric(50),
    "100" = getSVDMetric(100),
    "250" = getSVDMetric(250),
    "500" = getSVDMetric(500),
    "1000" = getSVDMetric(1000)
)

rmses <- sapply(aout, FUN = function(x) { return((x$rmse)) })
# 10           25           50          100          250          500 
# 0.1054151579 0.0406980522 0.0191884753 0.0097571452 0.0037773619 0.0021951624 
# 1000 
# 0.0009995816 

biases <- sapply(aout, FUN = function(x) { return( abs(x$bias) ) })
# 10           25           50          100          250          500 
# 1.312014e-03 9.553654e-03 4.431569e-03 1.423871e-03 7.269182e-05 1.710747e-04 
# 1000 
# 1.332572e-04 


##################
# Same Thing for rSVDdpd

aout.rob <- list(
    "10" = getSVDMetric(10, robust = T),
    "15" = getSVDMetric(15, robust = T),
    "20" = getSVDMetric(20, robust = T),
    "25" = getSVDMetric(25, robust = T),
    "35" = getSVDMetric(35, robust = T),
    "50" = getSVDMetric(50, robust = T),
    "100" = getSVDMetric(100, robust = T),
    "250" = getSVDMetric(250, robust = T),
    "500" = getSVDMetric(500, robust = T),
    "1000" = getSVDMetric(1000, robust = T)
)

rmses.rob <- sapply(aout.rob, FUN = function(x) { return((x$rmse)) })

biases.rob <- sort(sapply(aout.rob, FUN = function(x) { return( abs(x$bias) ) }), decreasing = T)

df <- data.frame(n = as.numeric(names(rmses.rob)), RMSE = rmses.rob, Bias = biases.rob)
ggplot(df, aes(x=n)) +
    geom_line( aes(y=RMSE, color = "red")) + 
    geom_line( aes(y=Bias / 0.3, color = "blue")) +
    geom_point( aes(y=RMSE, color = "red")) + 
    geom_point( aes(y=Bias / 0.3, color = "blue")) +
    scale_y_continuous(
        # Features of the first axis
        name = "RMSE",
        # Add a second axis and specify its features
        sec.axis = sec_axis(~.*0.3, name="Bias")
    ) + scale_x_continuous(trans = "log10") +
    scale_color_manual(
        name = 'Metric',
        values = c('red' = 'red', 'blue' = 'blue'),
        labels = c('RMSE', 'Bias')
    ) + theme_custom()
    












