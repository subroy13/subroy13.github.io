# GoDec Algorithm
# Source: Tianyi Zhou and Dacheng Tao, 
# "GoDec: Randomized Lo-rank & Sparse Matrix Decomposition in Noisy Case", ICML 2011
# Input:
#     - X : n x p data matrix
#     - rank : rank(L) <= rank 
#     - card : card(S) / size(S) <= card 
#     - power: >= 0, power scheme modification, increasing it lead to better accuracy and more time cost

GoDec <- function(X, rank = 2, card = 0.1, power = 0, maxiter = 100, tol = 1e-3) {

    # ------------
    # initialization
    iter <- 1
    m <- nrow(X); n <- ncol(X)
    if (m < n) {
        X <- t(X)
    }    

    L <- X
    S <- matrix(0, nrow = nrow(X), ncol = ncol(X))
    converged <- FALSE

    while(!converged) {
        
        # -----------
        # Updation for L
        Y2 <- matrix(rnorm(n * rank), nrow = n, ncol = rank)
        for (i in 1:(power + 1)) {
            Y2 <- crossprod(L) %*% Y2
        }
        qrobj <- qr(Y2)
        Q <- qr.Q(qrobj)
        R <- qr.R(qrobj)
        L_new <- L %*% tcrossprod(Q)

        # ---------------
        # Updation for S
        T <- L - L_new + S
        L <- L_new 
        sorted_vals <- sort(abs(T), decreasing = TRUE, index.return = TRUE)
        card_value <- round(m * n * card)
        S <- matrix(0, nrow = nrow(X), ncol = ncol(X))
        S[sorted_vals$ix[1:card_value]] <- T[sorted_vals$ix[1:card_value]]

        # ----------- 
        # Check for stopping criterion
        E <- X - L - S 
        err <- norm(E, "F") / norm(X, "F")
        iter <- iter + 1
        if (err < tol) {
            converged <- TRUE
        }
        if (iter > maxiter) {
            converged <- TRUE
        }
        T[sorted_vals$ix[1:card_value]] <- 0
        if (!converged) {
            L <- L + T       
        }
    }

    if (m < n) {
        L <- t(L); S <- t(S)
    }

    return(list(
        "LR" = L,
        "Sparse" = S,
        "Noise" = (X - L - S)
    ))
}
