# This code implements the Sparsity Regularized Principal Component Pursuit method for robust PCA
# Objective: min |L|_* + Beta * |S|_0+lambda * |D-L-S|_1
# Source: Theoretical guarantees can be found at https://sites.google.com/a/eng.ucsd.edu/l0-magic/ and https://ieeexplore.ieee.org/document/8552462

# Input:
#     - X : m x n data matrix 
#     - beta : weight  on sparsity 
#     - lambda : weight on noise term 

srpcpRPCA <- function(X, beta = NA, lambda = NA, tol = 1e-4, maxiter = 100, L_pcp = NA) {
    outlier_threshold <- 10
    m <- nrow(X)
    n <- ncol(X)
    r <- min(m, n)
    if (is.na(lambda)) {
        lambda <- 1/sqrt(max(m, n))
    }
    if (is.na(beta)) {
        beta <- lambda * outlier_threshold
    }

    S <- matrix(0, nrow = m, ncol = n)
    L_pre <- X
    L <- matrix(0, nrow = m, ncol = n)
    Xnorm <- norm(X, "F")
    iter <- 0
    err <- Inf

    while ((iter < maxiter) & (err > tol)) {
        L_pre <- L

        # ----------------
        # Step 1

        S_pre <- S
        if (iter == 1) {
            # initialization step
            if (is.na(L_pcp)) {
                L <- almRPCA(X)
            } else {
                L <- L_pcp
            }
        } else {
            L <- RMC(X - S, (S == 0), L, S, lambda)
        }

        lhs <- sum(svd(L, nu = r, nv = r)$d[1:r]) + lambda * sum( abs((X - L) * (S == 0)) )
        rhs <- sum(svd(L_pre, nu = r, nv = r)$d[1:r]) + lambda * sum( abs((X - L_pre) * (S == 0)) )
        if (lhs == rhs) {
            L <- L_pre 
            break
        }

        # ----------------------------
        # step 2
        S <- (X - L)
        S[abs(S) <= beta / lambda] <- 0
        if (norm(S - S_pre, "F") == 0) {
            break
        }

        iter <- iter + 1
        err <- norm(L - L_pre, "F")/Xnorm
    }

    return(list(
        "LR" = L,
        "Sparse" = S,
        "Noise" = (X - L - S)
    ))

}

# Utility submodule (RMC) - Robust Matrix Completion
# Input:
    # - X : m x n data matrix
    # - Omega : m x n logical mask, TRUE means observed
    # - lambda : weight on sparse error term 
    # - tol : stopping criterion DEFAULT 1e-7
    # - maxiter : maximum number of iteration DEFAULT 1000

RMC <- function(X, Omega, A_hat, E_hat, lambda = NA, tol = 1e-7, maxiter = 1000) {
    m <- nrow(X)
    n <- ncol(X)
    r <- min(m, n)
    if (is.na(lambda)) {
        lambda <- 1/sqrt(max(m, n))
    }

    # -------------------
    # Initialization
    Y <- sign(X)
    norm_two <- norm(Y, "2")
    norm_inf <- norm(Y, "I") / lambda 
    dual_norm <- max(norm_two, norm_inf)
    Y <- Y / dual_norm

    Xnorm <- norm(X, "F")
    tolProj <- 1e-6 * Xnorm
    total_svd <- 0
    mu <- 0.5 / norm_two   # can be tuned
    rho <- 6        # can be tuned

    iter <- 0
    converged <- FALSE

    sv <- 5

    while (!converged) {
        iter <- iter + 1

        # --------------------
        # Solve the primal problem by alternating projection
        primal_converged <- FALSE
        primal_iter <- 0
        sv <- min(sv + round(r * 0.1), r)

        while (!primal_converged) {
            temp_T <- X - A_hat + Y/mu 
            temp_E <- pmax(temp_T - lambda / mu, 0) + pmin(temp_T + lambda/mu, 0)
            temp_E[Omega == FALSE] <- temp_T[Omega == FALSE]

            svditer <- svd(X - temp_E + Y/mu, nu = sv, nv = sv)
            U <- svditer$u[,1:sv] 
            V <- svditer$v[, 1:sv] 
            diagS <- svditer$d[1:sv]
            svp <- sum(diagS > 1/mu)
            if (svp < sv) {
                sv <- min(svp + 1, r)
            } else {
                sv <- min(svp + round(0.05 * r), r)
            }
            if (svp <= 1) {
                temp_A <- (U[, 1] %*% t(V[, 1])) * max(diagS[1] - 1/mu, 1e-3)
            } else {
                temp_A <- U[, 1:svp] %*% diag(diagS[1:svp] - 1/mu) %*% t(V[, 1:svp])
            }
            
            norm_A_err <- norm(A_hat - temp_A, "F")
            norm_E_err <- norm(E_hat - temp_E, "F")
            if ((norm_A_err < tolProj) & (norm_E_err < tolProj)) {
                primal_converged <- TRUE
            }
            if (primal_iter > 50) {
                primal_converged <- TRUE
            }
            A_hat <- temp_A 
            E_hat <- temp_E 
            primal_iter <- primal_iter + 1
            total_svd <- total_svd + 1
        }

        Z <- X - A_hat - E_hat
        Y <- Y + mu * Z
        mu <- rho * mu

        stopcriterion <- norm(Z, "F") / Xnorm
        if (stopcriterion < tol) {
            converged <- TRUE
        }
        if (iter >= maxiter) {
            converged <- TRUE
        }

    }

    return(A_hat)
}




