##########################
# Perform background modelling with different Video Modelling Algorithms for the BMC Dataset (2012)
# LOAD REQUIRED PACKAGES
library(imager)
library(stringr)
library(imager)
library(rsvddpd)
library(rpca)

########################
# Load existing video surveillance methods
##############################

# Source Other methods
source('./scripts/rpca_VB.R')
source('./scripts/GoDec.R')
source('./scripts/rpca_ALM.R')
source('./scripts/rpca_OP.R')

bg.model <- function(frames, method = "rsvddpd", nd = 1) {
  
  convert_matrix_to_frame <- function(M, shapes) {
    img_w <- shapes[1]
    img_h <- shapes[2]
    img_d <- ncol(M)
    stopifnot(nrow(M) == img_w * img_h)
    dim(M) <- c(img_w, img_h, img_d, 1)
    return(as.cimg(M))
  }
  
  
  frames.bw <- grayscale(frames)
  
  # convert frame to Matrix
  shapes <- dim(frames.bw)
  M <- as.numeric(frames.bw)
  dim(M) <- c(shapes[1] * shapes[2], shapes[3])
  
  # Now we perform the robust SVD
  if (method == "svd") {
    ts <- system.time({
      suppressWarnings({
        out <- svd(M, nu = 1, nv = 1)
      })
    }) 
    
    L <- out$d[1] * out$u[, 1] %*% t(out$v[, 1])  # the low rank component
  } else if (method == "rsvddpd") {
    ts <- system.time({
      suppressWarnings({
        out <- rSVDdpd(M, 0.5, nd = nd)
      })
    }) 
    if (nd == 1) {
      L <- out$d[1] * out$u[, 1] %*% t(out$v[, 1])  # the low rank component
    } else {
      L <- out$u[, 1:nd] %*% diag(out$d[1:nd]) %*% t(out$v[, 1:nd])  # the low rank component
    }
  } else if (method == "rsvddpd2") {
      nd <- 2
      ts <- system.time({
          suppressWarnings({
              out <- rSVDdpd(M, 0.5, nd = nd)
          })
      }) 
    L <- out$u[, 1:nd] %*% diag(out$d[1:nd]) %*% t(out$v[, 1:nd])  # the low rank component
  } else if (method == "rpca") {
    # Now we perform the robust SVD
    ts <- system.time({
      suppressWarnings({
        out <- rpca(M)
      })
    }) 
    L <- out$L  # the low rank component
  } else if (method == "GoDec") {
    ts <- system.time({
      suppressWarnings({
        out <- GoDec(M)
      })
    }) 
    L <- out$LR  # the low rank component
  } else if (method == "ALM") {
    ts <- system.time({
      suppressWarnings({
        out <- rpca_ALM(M)
      })
    }) 
    L <- out$LR  # the low rank component
  } else if (method == "VB") {
    ts <- system.time({
      suppressWarnings({
        out <- rpca_VB(M)
      })
    }) 
    L <- out$LR  # the low rank component
  } else if (method == "OP") {
    ts <- system.time({
      suppressWarnings({
        out <- rpca_OP(M)
      })
    })
    L <- out$LR  # the low rank component
  } else if (method == "GRASTA") {
    ts <- system.time({
      suppressWarnings({
        out <- grasta(M)
      })
    })
    L <- out$LR  # the low rank component
  } else {
    stop("Not implemented yet!")
  }
  
  E <- M - L   # the error foreground model
  
  # convert both all components into cimg
  return(list(
    "Video" = convert_matrix_to_frame(M, shapes),
    "Background" = convert_matrix_to_frame(L, shapes),
    "Foreground" = convert_matrix_to_frame(E, shapes),
    "Time" = ts
  ))
  
}


#########################
# Utility functions

# Unzip the files
# unzip('./data/BMC/bmc_synth1.zip', exdir = './data/BMC')
# unzip('./data/BMC/bmc_synth2.zip', exdir = './data/BMC')
# unzip('./data/BMC/bmc_real.zip', exdir = './data/BMC')

get.synth.filepaths <- function(rootpath) {
  synth1.list <- list.files(file.path(rootpath, 'synth1'))
  synth2.list <- list.files(file.path(rootpath, 'synth2'))
  files <- c(
    file.path(rootpath, 'synth1', synth1.list[-grep("_gt.mp4", synth1.list)]),
    file.path(rootpath, 'synth2', synth2.list[-grep("_gt.mp4", synth2.list)])
  )
  gt_files <- c(
    file.path(rootpath, 'synth1', synth1.list[grep("_gt.mp4", synth1.list)]),
    file.path(rootpath, 'synth2', synth2.list[grep("_gt.mp4", synth2.list)])
  )
  names(files) <- names(gt_files) <- as.character(str_match(files, "[0-9]{3,}"))
  return(list("video" = files, "gt" = gt_files))
}


# Performs simulation, saves the time and the background video
simulation <- function(methodname) {
  f <- get.synth.filepaths('./data/BMC')
  for (b in names(f$video)) {
    message(paste0("Processing video: ", f$video[b]))
    video <- load.video(f$video[b], fps = 2)   # use FPS = 2 for memory size issue
    tryCatch({
      result <- bg.model(video, method = methodname)     
    }, error = function(cond) {
      message("ERROR!")
      return(NA)
    })
    
    # only save the background video (can extract fg by subtracting)
    output_bg_path <- paste0('./output/BMC/',methodname,'/bg-', b, '.mp4')
    output_ts_path <- paste0('./output/BMC/',methodname,'/ts.txt')
    save.video(result$Background, output_bg_path, fps = 2)
    write(paste0("Video: ", b, "\tTime:", as.numeric(result$Time["elapsed"]) ), 
          file = output_ts_path, append = TRUE)
  }
}

methodname <- "rsvddpd2"
simulation(methodname)




















