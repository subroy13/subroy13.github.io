# This code implements the Augmented Lagrange Multiplier method for Robust PCA
# Source:
# Minming Chen, October 2009. Questions? v-minmch@microsoft.com ; Arvind Ganesh (abalasu2@illinois.edu)
# Copyright: Perception and Decision Laboratory, University of Illinois, Urbana-Champaign  ;Microsoft Research Asia, Beijing

# Objective: L(A,E,Y,u) = |A|_* + lambda * |E|_1 + <Y,D-A-E> + mu/2 * |D-A-E|_F^2
# Input:
#     - X: m x n data matrix
#     - lambda : weight on sparse error term in the cost function 
#     - tol : stopping criterion DEFAULT 1e-7
#     - maxiter: maximum number of iteration DEFAULT 1000

rpca_ALM <- function(X, lambda = NA, tol = 1e-7, maxiter = 1000) {
    m <- nrow(X)
    n <- ncol(X)
    r <- min(m, n)
    if (is.na(lambda)) {
        lambda <- 1/sqrt(max(m,n))
    }

    # -----------------
    # initialization step
    Y <- sign(X)
    norm_two <- norm(Y, "2")
    norm_inf <- norm(Y, "I") / lambda
    dual_norm <- max(norm_two, norm_inf)
    Y <- Y / dual_norm

    A_hat <- matrix(0, nrow = m, ncol = n)
    E_hat <- matrix(0, nrow = m, ncol = n)
    Xnorm <- norm(X, "F")
    tolProj <- 1e-6 * Xnorm 
    total_svd <- 0
    mu <- 0.5 / norm_two   # this can be tuned
    rho <- 6        # this can be tuned

    iter <- 0
    converged <- FALSE
    sv <- 5

    while (!converged) {
        iter <- iter + 1

        # --------------------
        # Solve the primal problem by alternating projection
        primal_converged <- FALSE
        primal_iter <- 0
        sv <- min(sv + round(r * 0.1), r)

        while (!primal_converged) {
            temp_T <- X - A_hat + Y/mu 
            temp_E <- pmax(temp_T - lambda / mu, 0) + pmin(temp_T + lambda/mu, 0)

            svditer <- svd(X - temp_E + Y/mu, nu = sv, nv = sv)
            U <- as.matrix(svditer$u[,1:sv])
            V <- as.matrix(svditer$v[, 1:sv]) 
            diagS <- svditer$d[1:sv]
            svp <- sum(diagS > 1/mu)
            if (svp < sv) {
                sv <- min(svp + 1, r)
            } else {
                sv <- min(svp + round(0.05 * r), r)
            }
            if (svp <= 1) {
                temp_A <- (U[, 1] %*% t(V[, 1])) * max(diagS[1] - 1/mu, 1e-3)
            } else {
                temp_A <- U[, 1:svp] %*% diag(diagS[1:svp] - 1/mu) %*% t(V[, 1:svp])
            }
            
            norm_A_err <- norm(A_hat - temp_A, "F")
            norm_E_err <- norm(E_hat - temp_E, "F")
            if ((norm_A_err < tolProj) & (norm_E_err < tolProj)) {
                primal_converged <- TRUE
            }
            if (primal_iter > 50) {
                primal_converged <- TRUE
            }
            A_hat <- temp_A 
            E_hat <- temp_E 
            primal_iter <- primal_iter + 1
            total_svd <- total_svd + 1
        }

        Z <- X - A_hat - E_hat
        Y <- Y + mu * Z
        mu <- rho * mu

        stopcriterion <- norm(Z, "F") / Xnorm
        if (stopcriterion < tol) {
            converged <- TRUE
        }
        if (iter >= maxiter) {
            converged <- TRUE
        }

    }

    return(list(
        "LR" = A_hat,
        "Sparse" = E_hat,
        "Noise" = Z
    ))



}

# m = 100
# n = 50
# r = 10  #rank of the low-rank component
# 
# A = matrix(rnorm(m*r), nrow = m, ncol = r)
# B = matrix(rnorm(n*r), nrow = r, ncol = n)
# X_true = A %*% B # low rank component
# 
# out <- almRPCA(X_true)
# out2 <- srpcpRPCA(X_true, L_pcp = out$LR)







