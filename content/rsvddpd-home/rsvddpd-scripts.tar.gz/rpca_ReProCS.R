# % Han Guo, Chenlu Qiu, Namrata Vaswani 
# % Reference: An Online Algorithm for Separating Sparse and Low-dimensional Signal Sequences from their Sum,
# %            accepted by IEEE Transaction on Signal Processing
library(CVXR)


rpca_ReProCS <- function(I) {
    Kmin <- 3
    Kmax <- 10
    alpha <- 20
    b <- 0.95
    p <- nrow(I); q <- ncol(I)

    # ------------------
    # Mean subtractions
    mu0 <- rowMeans(I)
    M <- I - matrix(mu0, nrow = p, ncol = q, byrow = FALSE)
    svdinit <- svd(1/sqrt(q) * M)

    evals <- svdinit$s^2
    energy <- sum(evals)
    cum_evals <- cumsum(evals)
    ind0 <- which(cum_evals < b * energy)   # find the index where b-proportion of energy is explained
    rhat <- min(length(ind0), round(q/10))
    lambda_min <- evals[rhat]
    U0 <- as.matrix(svdinit$u[, 1:rhat])

    # ----------------
    # ReProCS Algorithm

    Shat_mod <- matrix(0, nrow = p, ncol = q)
    Lhat_mod <- matrix(0, nrow = p, ncol = q)
    Nhat_mod <- as.list(numeric(q))
    Fg <- matrix(0, nrow = p, ncol = q)
    Bg <- matrix(0, nrow = p, ncol = q)
    xcheck <- matrix(0, nrow = p, ncol = q)
    Tpred <- c()
    Ut <- U0 

    Pstar <- Ut 
    k <- 0
    K <- c()
    addition <- 0
    cnew <- c()
    t_new <- c()
    time_upd <- c()
    thresh_diff <- c()
    thresh_base <- c()
    thresh <- numeric(q)

    for (t in 1:q) {
        opts <- list(
            "tol" = 1e-3,
            "print" = FALSE
        )
        yt <- Projection(Ut, M[, t])

        # decide noise
        if (y == 1) {
            opts$delta <- normval(Projection(Ut, I[, 1]))
            delta_last <- opts$delta
        } else {
            opts$delta <- normval(Projection(Ut, Lhat_mod[, t-1]))
        }

        if (opts$delta / delta_last < 0.5) {
            opts$delta <- delta_last
        }

        if ((t == 1) || (t == 2)) {
            xp <- yall1(Ut, yt, opts)$xp 
            omega_t <- normval(M[, t])/sqrt(p)
            That <- which(abs(xp) >= omega_t)
        } else {
            if (Nhat_mod[[t-2]][1] == 0) {
                thresh[t] <- 0
            } else {
                thresh[t] <- length(intersect(Nhat_mod[[t-1]], Nhat_mod[[t-2]])) / length(Nhat_mod[[t-2]])
                lambda1 <- length(setdiff(Nhat_mod[[t-2]], Nhat_mod[[t-1]])) / length(Nhat_mod[[t-1]])
            }

            if (thresh[t] < 0.5) {
                xp <- yall1(Ut, yt, opts)$xp 
                omega_t <- normval(M[, t])/sqrt(p)
                That <- which(abs(xp) >= omega_t)
            } else {
                weights <- rep(1, p)
                weights[Tpred] <- lambda1
                opts$weights <- weights
                xp <- yall1(Ut, yt, opts)$xp 
                xpsorted <- sort(abs(xp), decreasing = T, index.return = T)
                xp <- xpsorted$x 
                ind <- xpsorted$ix 
                Tcheck <- ind[1:round(min(1.4 * length(Tpred), 0.6 * p))]
                xcheck[Tcheck, t] <- subLS(Ut, Tcheck, yt)   # TO DO??
                omega_t <- normval(M[, t])/sqrt(p)
                That <- which(abs(xcheck[,t]) >= omega_t)
            }
        }

        Shat_mod[That, t] <- subLS(Ut, That, yt)  # TO DO??
        Lhat_mod[, t] <- M[, t] - Shat_mod[, t]
        Fg[That, t] <- I[That, t]
        Nhat_mod[[t]] <- That
        Tpred <- That
        Bg[, t] <- Lhat_mod[, t] + mu0

        # ------------
        # Projection PCA
        if (addition == 0) {
            addition <- 1
            t_new <- t
            Pnewhat <- c()
            k <- 0
        }

        if ((addition == 1) && ((t - t_new+1) %% alpha == 0)) {
            time_upd <- c(time_upd, t)
            D <- Lhat_mod[, (t-alpha+1):t] - tcrossprod(Pstar) %*% Lhat_mod[, (t-alpha+1):t]

            svdres <- svd(D/sqrt(alpha))
            Pnew_hat <- svdres$u
            Lambda_new <- svdres$d^2
            Lambda_new <- Lambda_new[Lambda_new >= lambda_min]
            th <- round(rhat/3)
            if (length(Lambda_new) > th) {
                Lambda_new <- Lambda_new[1:th]
            }

            if (length(Lambda_new) == 0) {
                addition <- 0
                cnew <- c(cnew, 0)
            } else {
                cnew_hat <- length(Lambda_new)
                Pnewhat_old <- Pnewhat
                Pnewhat <- Pnew_hat[, 1:cnew_hat]
                cnew <- c(cnew, cnew_hat)
                Ut <- cbind(Pstar, Pnewhat)

                k <- k+1

                if (k == 1) {
                    temp <- tcrossprod(Pnewhat) %*% Lhat_mod[, (t-alpha+1):t]
                    thresh_base <- c(thresh_base, normval(temp/sqrt(alpha)))
                    thresh_diff <- c(thresh_diff, normval(temp/sqrt(alpha)))
                } else {
                    temp <- tcrossprod(Pnewhat) %*% Lhat_mod[, (t-alpha+1):t]
                    thresh_base <- c(thresh_base, normval(temp/sqrt(alpha)))
                    temp <- temp - tcrossprod(Pnewhat_old) %*% Lhat_mod[, (t-alpha+1):t]
                    thresh_diff <- c(thresh_diff, normval(temp/sqrt(alpha)))                    
                }

                flag <- FALSE
                if (k >= Kmin) {
                    numK <- 3
                    endindex <- length(thresh_diff)
                    flag <- thresh_diff[endindex] / thresh_diff[endindex-1] < 0.01
                    for (ik in 1:(numK - 1)) {
                        flag <- flag & (thresh_diff[endindex - ik] / thresh_diff[endindex-1-ik] < 0.01)
                    }
                }

                if ((k == Kmax) || ((k >= Kmin) && (flag == TRUE))) {
                    addition <- 0
                    K <- c(K, k)
                    Pstar <- Ut
                }
            }
        }
    }
}


Projection <- function(Pt, b, Tindex = NULL) {
    if (is.null(Tindex)) {
        y <- b - tcrossprod(Pt) %*% b
    } else {
        It <- diag(nrow(Pt))[, Tindex]
        y <- It %*% b - Pt %*% (t(Pt[Tindex, ]) %*% b)
    }
    return(y)
}

normval <- function(x) {
    if (length(dim(x)) < 2) {
        return(sqrt(sum(x^2)))
    } else {
        return(norm(x))
    }
}


yall1 <- function(Ut, yt, opts) {
    # the first argument specify two function handles
    # Atf.times(x) <- Projection(Ut, x)
    # Atf.trans(y) <- Projection(Ut, y)

    # % A solver for L1-minimization models:
    # % min ||Wx||_{w,1}, st Ax = b
    xhat <- Variable(cols = length(opts$weights))
    objective <- Minimize(abs(t(xhat) %*% opts$weights))
    cons1 <- (xhat >= 0)
    cons2 <- ((diag(nrow(Ut)) - tcrossprod(Ut)) %*% xhat == y)
    result <- solve(Problem(objective), constraints = list(cons1, cons2))
    return(list("xp" = result$getValue(xhat)))
}


subLS <- function(Pt, Tindex, y) {
    It <- diag(nrow(Pt))[, Tindex]
    Amat <- It - Pt %*% t(Pt[Tindex, ])

    # find the least square solution to Amat * x = y
    xhat <- solve(crossprod(Amat), crossprod(Amat, y))
    return(xhat)
}





