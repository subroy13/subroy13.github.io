# %  grasta_stream is the streaming version of GRASTA which can be used for
# %  online data processing
# %
# %   [1] Jun He, Laura Balzano, and John C.S. Lui. Online Robust Subspace Tracking from Partial Information
# %       http://arxiv.org/abs/1109.3827
# %   [2] Jun He, Laura Balzano, and Arthur Szlam. Incremental gradient on the grassmannian for online foreground 
# %       and background separation in subsampled video. In IEEE Conference on Computer Vision and Pattern Recognition 
# %       (CVPR), June 2012.
# %
# %  Usage:
# %       [ Unew, STATUSnew, OPTSnew ] = grasta_stream( y_Omega, idx, U0, STATUS, OPTIONS, OPTS)
# %   Inputs:
# %       y_Omega: current partial observation of a full data vector
# %       idx:     the observed indices of y_Omega
# %       U0:      the current estimated subspace
# %       STATUS:  the current status of GRASTA
# %           last_mu: \mu_{t-1} for adaptive step rule
# %           step_scale: the estimated step_scale constant for adaptive
# %       step-size rule
# %           lelve: the current level of the "Multi-Level" adaptive rule
# %           last_gamma and last_w: previous gradient = last_gamma*last_w'
# %
# %       OPTIONS: the options of GRASTA    
# %           CONSTANT_STEP: default 0, will use multi-level step-size rule; > 0 will
# %           use constant step-size rule
# %           DIM_M : the ambient dimension
# %           RANK  : the estimated low-rank of the underlying system
# %           rho : ADMM constant step 
# %           ITER_MAX: the max_iter for ADMM solver
# %           TOL : the stopping tolerance of admm_srp / mex_srp
# %
# %       OPTS:    the current options for the subproblem of GRASTA
# %           refer to mex_srp.cpp or admm_srp.m
# %   Outputs:
# %       Unew:    the updated subspace 
# %       STATUSnew: the updated running status
# %       OPTSnew: the updated options for the subproblem of GRASTA

library(pracma)

grasta_stream <- function(y_Omega, idx, U0 = NA, status = NULL, options = NULL, admm_opts = NULL) {
    if (is.null(options)) {
        options <- list(
            "min_mu" = 1,
            "max_mu" = 15,
            "constant_step" = 0,  # pass > 0 to specify step size
            "dim_m" = length(y_Omega), # ambient dimension
            "miniter" = 5,
            "maxiter" = 60,
            "tol" = 1e-6,
            "maxlevel" = 20,
            "rank" = 2,   # should specify the rank
            "rho" = 1.8,
            "level_factor" = 2
        )
    }

    default_mu_high <- (options$max_mu - 1)/2
    default_mu_low <- options$min_mu + 2

    # holds the current status values for GRASTA
    if (is.null(status)) {
        # if it is initialization
        status <- list(
            "init" = FALSE,
            "curr_iter" = 0,
            "last_mu" = options$min_mu,
            "level" = 0,
            "step_scale" = 0,
            "last_w" = numeric(options$rank),
            "last_gamma" = numeric(options$dim_m),
            "grad_ip" = 0
        )

        admm_opts <- list(
            "tol" = options$tol,
            "maxiter" = options$miniter,
            "rho" = options$rho
        )


        U0 <- orth(matrix(rnorm(options$dim_m * options$rank), nrow = options$dim_m, ncol = options$rank))
    }

    # ------------------
    # Main Framework of Grasta
    U_Omega <- U0[idx, ]  # subset only observed pixels
    admm_out <- admm_srp(U_Omega, y_Omega, admm_opts)
    ldual <- admm_out$y
    w <- admm_out$w
    s_t <- admm_out$s
    
    gamma_1 <- ldual
    UtDual_omega <- t(U_Omega) %*% gamma_1 
    gamma_2 <- U0 %*% UtDual_omega
    gamma <- numeric(options$dim_m)
    gamma[idx] <- gamma_1 
    gamma <- gamma - gamma_2
    gamma_norm <- sqrt(sum(gamma^2))
    w_norm <- sqrt(sum(w^2))
    sG <- gamma_norm * w_norm

    # % 1. determine the step scale from the first observation
    if (status$step_scale == 0) {
        status$step_scale <- 0.5 * pi * (1 + options$min_mu)/sG 
    }

    # % 2. inner product of previous grad and current grad
    grad_ip <- sum(diag(
        status$last_w %*% (t(status$last_gamma) %*% gamma) %*% t(w)
    ))
    # avoid too large inner products
    normalization <- norm(status$last_gamma %*% t(status$last_w), "F") * norm(gamma %*% t(w), "F")
    if (normalization == 0) {
        grad_ip_normalization <- 0
    } else {
        grad_ip_normalization <- grad_ip/normalization
    }

    # % 3. if the two consecutive grad in the same direction, we take a larger
    # % step along the gradient direction, otherwise take a small step along the
    # % gradient direction
    sigmoid <- function(x) {
        fmin <- -1
        fmax <- 1
        omega <- 0.1
        fval <- fmin + (fmax - fmin) / (1 - (fmax/fmin) * exp(-x/omega))
        return(fval)
    }

    status$last_mu <- max(
        status$last_mu + sigmoid(-grad_ip_normalization),
        options$min_mu
    )

    if (options$constant_step > 0) {
        t <- options$constant_step
    } else {
        t <- status$step_scale * options$level_factor^(-status$level) * sG / (1 + status$last_mu)
        if (t >= pi/3) {
            t <- pi/3
        }

        # Adjust the level
        bShrUpd = 0
        if (status$last_mu <= options$min_mu) {
            if (status$level > 1) {
                bShrUpd <- 1
                status$level <- status$level - 1
                status$curr_iter <- 0
            }
            status$last_mu <- default_mu_low
        } else if (status$last_mu > options$max_mu) {
            if (status$level < options$maxlevel) {
                bShrUpd <- 1
                status$level <- status$level + 1
                status$curr_iter <- 0
                status$last_mu <- default_mu_high
            } else {
                status$last_mu <- options$max_mu
            }
        }

        if (bShrUpd > 0) {
            if ((status$level >= 0) & (status$level < 4)) {
                admm_opts$maxiter <- options$miniter
            } else if ((status$level >= 4) & (status$level < 7)) {
                admm_opts$maxiter <- min(options$miniter*2, options$maxiter)
            } else if ((status$level >= 7) & (status$level < 10)) {
                admm_opts$maxiter <- min(options$miniter*4, options$maxiter)
            } else if ((status$level >= 10) & (status$level < 14)) {
                admm_opts$maxiter <- min(options$miniter*8, options$maxiter)
            } else {
                admm_opts$maxiter <- options$maxiter
            }
        }

    }

    # 4. update the gradient for further step size update
    status$last_gamma <- gamma 
    status$last_w <- w 
    status$grad_ip <- grad_ip_normalization

    # take the gradient step along Grassmannian geodesic
    alpha <- w / w_norm
    beta <- gamma / gamma_norm
    step <- (cos(t) - 1)* U0 %*% tcrossprod(alpha) - sin(t) * beta %*% t(alpha)
    U0 <- U0 + step

    status$s_t <- s_t
    status$w <- w
    status$ldual <- ldual
    status$scale <- 1
    status$curr_iter <- status$curr_iter + 1
    status$grasta_t <- t

    return(list("U0" = U0, "status" = status, "admm_opts" = admm_opts, "LR" = U0 %*% w ))

} 


# Submodule function
# Solve sparse residual pursuit (SRP) via ADMM {S.Boyd 2011}
# % Solves the following problem via ADMM:
# % 
# %   minimize     ||s||_1
# %   subject to   Uw + s- v = 0
# %   y is the dual vector

admm_srp <- function(U, v, options = NULL) {
    if (is.null(options)) {
        options <- list(
            "rho" = 1.8,
            "maxiter" = 50,
            "tol" = 1e-7
        )
    }

    # submodule
    shrinkage <- function(a, kappa) {
        y <- pmax(0, a - kappa) - pmax(0, -a-kappa)
        return(y)
    }

    # Initialization parts
    m <- nrow(U)
    n <- ncol(U)
    w <- numeric(n)
    s <- numeric(m)
    y <- numeric(m)
    mu <- 1.25/sqrt(sum(v^2))

    P <- solve(crossprod(U), t(U))

    # ---------
    # iteration
    converged <- FALSE
    iter <- 0

    while(!converged) {
        iter <- iter + 1
        
        # w -update
        w <- P %*% (v - s - y/mu)

        # s -update
        Uw <- U %*% w 
        s <- shrinkage(v - Uw - y/mu, 1/mu)

        # y -update
        h <- Uw + s - v
        y <- y + mu * h

        mu <- options$rho * mu

        if (sqrt(sum(h^2)) < options$tol) {
            converged <- TRUE
        }

        if (iter >= options$maxiter) {
            converged <- TRUE
        }
    }

    return(list("s" = s, "w" = w, "y" = y))
}


# performs grasta over the matrix whose columns denote the pixels
grasta <- function(M) {
    n <- nrow(M)
    p <- ncol(M)
    
    L <- matrix(0, nrow = n, ncol = p)
    S <- matrix(0, nrow = n, ncol = p)
    
    # initial step in grasta
    grasta_out <- grasta_stream(M[, 1], 1:n)
    L[,1] <- grasta_out$LR
    S[, 1] <- grasta_out$status$s_t
    
    for (i in 2:p) {
        grasta_out <- grasta_stream(M[, i], 1:n, grasta_out$U0, status = grasta_out$status, admm_opts = grasta_out$admm_opts)
        L[,i] <- grasta_out$LR
        S[, i] <- grasta_out$status$s_t
    }
    
    return(list(
        "LR" = L,
        "Sparse" = S,
        "Noise" = (M - L - S)
    ))
}















